## Load necessary libraries
library(MachineShop)
library(recipes)

## Helper Functions

## x not in y 
`%!in%` <- function(x,y)!(x %in% y)

## rename the columns of a data frame using a pipeline-able function 
colrename <- function(df, name_swaps = NULL){
  if(!is.null(name_swaps) & (length(name_swaps) < ncol(df))){
    for(xyz in 1:length(name_swaps)){
      split <- strsplit(name_swaps[xyz],"=") %>% unlist %>% trimws
      colnames(df)[colnames(df)==split[1]] <- split[2]
    }}else{
      colnames(df) <- name_swaps
    }   
  return(df)
}

################################################################################

  ## AMES

# data provided by https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data

train <- read.csv('train.csv',stringsAsFactors = F)
seed <- 52246
set.seed(seed)
train$Id <- NULL
for(j in 1:ncol(train)){
  if(class(train[1,j]) %in% c('factor','character')){
    ## for missing categoricals, treat missing as its own category
    train[,j] <- as.character(train[,j])
    train[,j][is.na(train[,j])] <- "Missing"
  } else {
    ## missing numerics will be imputed
    invisible()
  }
}
train <- train[,apply(train,2,function(x)length(unique(x)) > 1)]
prep_rec <- recipe(SalePrice ~ .,
              data = train) %>%
  step_dummy(all_nominal_predictors())
dat <- prep_rec %>%
  step_impute_knn(all_numeric_predictors(),
                  neighbors = 25) %>% 
  prep %>%
  juice
dat <- dat[,apply(dat,2,function(x)min(table(x)) > 2 | 
            length(unique(x)) > 2)]
rec <- recipe(SalePrice ~ .,
              data = dat)
save(rec,
     file = "ames.RData")
################################################################################

  ## MNIST 

## Libraries 
library(foreach)
library(doParallel)

## functions provided by Dr. Grant Brown UIowa/2021
readMNISTImages <- function(fname){
  imgCon = file(fname, "rb")
  magicNumber = readBin(imgCon, "int", n = 1, size = 4, endian = "big")
  nImg = readBin(imgCon, "int", n = 1, size = 4, endian = "big")
  nRow = readBin(imgCon, "int", n = 1, size = 4, endian = "big")
  nCol = readBin(imgCon, "int", n = 1, size = 4, endian = "big")
  
  imageList = lapply(1:nImg, function(x){
    matrix(as.numeric(readBin(imgCon, "int", n = nRow*nCol, size = 1, endian = "big")),
           nrow = nRow, ncol = nCol)
  })
  close(imgCon)
  imageList
}
readMNISTLabels <- function(fname){
  labCon = file(fname, "rb")
  magicNumber = readBin(labCon, "int", n = 1, size = 4, endian = "big")
  nItems = readBin(labCon, "int", n = 1, size = 4, endian = "big")
  imageLabels = sapply(1:nItems, function(x){
    readBin(labCon, "int", n = 1, size = 1, endian = "big", signed = FALSE)
  })
  close(labCon)
  imageLabels
}

## data Prep
train_img <- readMNISTImages("train-images.idx3-ubyte")
train_labels <- readMNISTLabels("train-labels.idx1-ubyte")
test_img <- readMNISTImages("./t10k-images.idx3-ubyte")
test_labels <- readMNISTLabels("./t10k-labels.idx1-ubyte")

## convert to long form in parallel
cl <- makeCluster(5)
registerDoParallel(cl)
training_data <- foreach(i = 1:length(train_img),
                      .combine = 'rbind',
                      .packages = 'magrittr') %dopar% {
                        img <- train_img[[i]]
                        vectorized <- t(sapply(1:ncol(img),function(i)c(img[,i]))) %>% 
                          as.data.frame
                        vectorized$column <- 1:nrow(vectorized)
                        vectorized$image <- i
                        vectorized
                        
                      }
test_data <- foreach(i = 1:length(test_img),
                      .combine = 'rbind',
                     .packages = 'magrittr') %dopar% {
                        img <- test_img[[i]]
                        vectorized <- t(sapply(1:ncol(img),function(i)c(img[,i]))) %>% 
                          as.data.frame
                        vectorized$column <- 1:nrow(vectorized)
                        vectorized$image <- i
                        vectorized
                      }
stopCluster(cl)

## save training and test separately
training_data = data.frame(Y = rep(as.factor(train_labels),
                                   each = ncol(training_data)-2),
                           X = training_data)
test_data = data.frame(Y = rep(as.factor(test_labels),
                               each = ncol(test_data)-2),
                           X = test_data)
shared_cols <- colnames(test_data)[colnames(test_data) %in% 
                                      colnames(training_data)]
training_data <- training_data[,shared_cols]
test_data <- test_data[,shared_cols]
rec <- recipe(Y ~ ., data = training_data) %>%
  role_case(stratum = Y)
save(rec,file = 'mnist_train_conv.RData')
rec <- recipe(Y ~ ., data = test_data) %>%
  role_case(stratum = Y)
save(rec,file = 'mnist_test_conv.RData')

################################################################################
  
  ## HNSCC ## 

## Libraries
library(survival)

## prior publication dataset 2
## from https://wiki.cancerimagingarchive.net/display/Public/HNSCC
## 1/21/2023
data <- read.csv("Radiomics_Outcome_Prediction_in_OPC_ASRM_corrected.csv") %>%
  colrename(c("Age.at.Diag = age",
              "Gender = sex",
              "T.category = t_stage",
              "N.category = n_stage",
              "Cancer.subsite.of.origin = index_tumour_location",
              "Overall.survival_duration.of.Merged.updated.ASRM.V2 = overall_survival_in_days",
              "Vital.status = event_overall_survival")) %>%
  mutate(event_overall_survival = as.numeric(factor(event_overall_survival,
                                                    levels = c("Alive","Dead")))-1)
data <- na.omit(data[,c(
  'TCIA.Radiomics.dummy.ID.of.To_Submit_Final',
  'sex',
  'age',
  'Smoking.status',
  'Smoking.status..Packs.Years.',
  'Tumor.laterality',
  'index_tumour_location',
  'HPV.Status',
  't_stage',
  'n_stage',
  'AJCC.Stage..7th.edition.',
  'Therapeutic.Combination',
  'Radiation.Treatment_duration',
  'Total.prescribed.Radiation.treatment.dose',
  'Radiation.treatment_number.of.fractions',
  'Radiation.treatment_dose.per.fraction',
  'event_overall_survival',
  'overall_survival_in_days',
  'Freedom.from.distant.metastasis',
  'Freedom.from.distant.metastasis_duration.of.Merged.updated.ASRM.V2'
)])
data <- as.data.frame(data)
data$t_stage <- factor(data$t_stage,levels = c(1,2,3,4))
data$n_stage <- factor(data$n_stage,levels = c(0,1,2,3))
data$y <- Surv(data$overall_survival_in_days,
               data$event_overall_survival)
temp_dat <-  
  recipe(y ~ ., data = data %>%
           dplyr::select(-TCIA.Radiomics.dummy.ID.of.To_Submit_Final,
                         event_overall_survival,
                         overall_survival_in_days)) %>%
  step_dummy(all_nominal_predictors()) %>% 
  prep %>%
  juice %>% 
  as('matrix') %>% 
  apply(2,as.numeric) %>% 
  na.omit %>%
  as.data.frame %>% 
  mutate(y = data$y)
colnames(temp_dat)[grepl('[.]',colnames(temp_dat))] <- 
  sapply(colnames(temp_dat)[grepl('[.]',colnames(temp_dat))],
         function(x)paste0(unlist(strsplit(x,
                                           '[.]')),
                           collapse = ""))
rec <- recipe(y ~ .,data = temp_dat[,-which(colnames(temp_dat) %in% c("event_overall_survival",
                                                                      "overall_survival_in_days",
                                                                      'ytime',
                                                                      "ystatus",
                                                                      "Freedomfromdistantmetastasis_durationofMergedupdatedASRMV2",
                                                                      "HPVStatus_Unknown",
                                                                      "Localcontrol_duration",
                                                                      "Regionalcontrol_duration",
                                                                      "Localcontrol_Yes"))]) %>% 
  role_case(stratum = y)
save(rec,file = "HNSCC.RData")

################################################################################

  ## MICROBIOME ## 
    
## Libraries
library(phyloseq)
library(mia)
library(curatedMetagenomicData)
library(MachineShop)
library(recipes)

## function for trying out different popular types of normalizations 
## for microbiome data
## (BiocManager::install for other packages required)
Normalize <- function(table,norm){
  
  normed_table <- as(table,"matrix")
  
  ## remove OTU with no counts present
  ind_all_zeroes <- which(colSums(table > 0) <= 1)
  ind_non_zeroes <- which(colSums(table > 0) > 1)
  if(length(ind_all_zeroes) == 0){
    tablee <- as(table,"matrix")
  } else{
    tablee <- as(table,"matrix")[,ind_non_zeroes]
    tablef <- as(table,"matrix")[,ind_all_zeroes]
  }
  
  ## RANK
  if(norm == "RANK"){
    normed <- apply(tablee, 2, rank)
  }
  
  ## TSS
  if(norm == "TSS"){
    r <- apply(tablee, 2, function(x)x/sum(x))
    normed <- apply(r,2,function(x)ifelse(is.nan(x)|is.na(x),
                                          0,
                                          x))
  }
  
  ## CSS
  if(norm == "CSS"){
    aux <- newMRexperiment(counts = tablee)
    normFacts <- metagenomeSeq::calcNormFactors(
      obj = aux, p = cumNormStatFast(aux))
    w <- drop(as.matrix(normFacts))
    r <- t(t(tablee) / w)
    normed <- apply(r,2,function(x)ifelse(is.nan(x)|is.na(x),
                                          0,
                                          x))
  }
  
  ## TMM
  if(norm == "TMM"){
    normFacts <- edgeR::calcNormFactors(tablee, method = "TMM")
    w <- normFacts * colSums(tablee,na.rm = TRUE)
    normed <- (t(t(tablee) / w))
  }
  
  ## rarefy
  if(norm == "RARE"){
    normed <- (phyloseq(otu_table(tablee,taxa_are_rows = T)) %>%
                 rarefy_even_depth(trimOTUs = FALSE) %>%
                 otu_table %>%
                 as('matrix'))
  }
  
  ## wrench
  if(norm == "WRENCH"){
    w <- Wrench::wrench(mat = tablee, condition = aux$condition)$nf
    normed <- (t(t(tablee) / w))
  }
  
  ## CLR
  if(norm == "CLR"){
    r <- (as(compositions::clr(tablee),"matrix"))
    normed <- apply(r,2,function(x)ifelse(is.nan(x)|is.na(x),
                                          0,
                                          x))
    
    ## set all missings to the minimum of the CLR'd values
    tablef <- min(normed)
    
  }
  
  ## Variance-stablizing transformation
  if(norm == "VST"){
    normed <- (DESeq2::varianceStabilizingTransformation(tablee+1,
                                                         fitType = 'local'))
  }
  
  ## NONE
  if(norm == "NONE"){
    normed <- (tablee)
  }
  
  if(length(ind_all_zeroes) > 0){
    normed_table[,ind_non_zeroes] <- normed
    normed_table[,ind_all_zeroes] <- tablef
  } else{
    normed_table <- normed
  }
  return(normed_table)
  
}

## turn a phyloseq object into a recipe
PhyseqToRecipe <- function(physeq,norm){
  
  ## microbe operational taxon units (OTUs)
  otu_table <- as(otu_table(physeq),
                  'matrix')
  
  ## apply normalization (Total-sum scaling done here, just divides by column sums)
  normalized_otus <- Normalize(otu_table,norm) %>%
    t %>%
    as.data.frame
  
  ## you're going to want to change the column names to just their species....
  colnames(normalized_otus) <- sapply(colnames(normalized_otus),
                                      function(x){
                                        rev(unlist(strsplit(x,'[|]')))[1]
                                      })
  
  ## subject level/demographic data
  sample_data <- as(sample_data(physeq),'data.frame')
  
  ## bind together subject level data and their sequenced fecal samples
  normalized_otus$id <- rownames(normalized_otus)
  sample_data$id <- rownames(sample_data)
  model_dat <- left_join(normalized_otus,sample_data,by = 'id') %>%
    select(c(colnames(normalized_otus),
             'study_condition',
             'age',
             'gender')) %>%
    select(-'id') %>% 
    na.omit %>%
    mutate(study_condition = factor(study_condition))
  
  ## recipe object
  recipe(study_condition ~ .,
         data = model_dat)
}

## merge phyloseq objects from a list given a shared condition they model 
MergePhyseq <- function(condition,datalist){
  ## for datasets
  ## bind conditions into one dataset
  condition_list <- datalist[
    grep(condition,
         c(lapply(datalist, function(x)sample_data(x) %>%
                    with(table(study_condition))) %>%
             lapply(function(x)names(x))))]
  
  ## create dataset variable to keep track of dataset names
  for(i in 1:length(condition_list)){
    s <- as.data.frame(sample_data(condition_list[[i]]),
                       stringsAsFactors = FALSE)
    s$dataset <- names(condition_list)[i]
    sample_data(condition_list[[i]]) <- sample_data(as.data.frame(s))
  }
  
  ## remove phy tree data, so no issues with "different tip lengths" etc.
  for(i in 1:length(condition_list)){
    condition_list[[i]]@phy_tree <- NULL
  }
  
  ## bind all the datasets together
  total_physeq <- condition_list[[1]]
  if(length(condition_list) > 1){
    for(i in 2:length(condition_list)){
      total_physeq <- merge_phyloseq(total_physeq,
                                     condition_list[[i]])
    }
  }
  
  return(total_physeq)
}

## For loading curatedMetagenomeSeq objects: 
## these are all the data sets that contain CRC info
datasets <- 
  c('FengQ_2015', 
    'GuptaA_2019',
    'HanniganGD_2017',
    'ThomasAM_2018a',
    'ThomasAM_2018b',
    'ThomasAM_2019_c',
    #'VogtmannE_2016'#, # Vogtmann was excluded, errors when downloading.... 
    'WirbelJ_2018',
    'YachidaS_2019',
    'YuJ_2015',
    'ZellerG_2014')
list <- list()
for(d in datasets){
  print("---------------")
  print(d)
  print("---------------")
  otus <- curatedMetagenomicData(d,
                                 counts = T,
                                 dryrun = FALSE)
  physeq <- try({
    mia::makePhyloseqFromTreeSummarizedExperiment(otus[grepl('relative_abundance',names(otus))][[1]],
                                                  abund_values = "relative_abundance") %>%
      subset_taxa(!is.na(species))
  },silent = T)
  if(any(class(physeq) == 'try-error')) {
    physeq <- try({
      mia::makePhyloseqFromTreeSummarizedExperiment(otus[grepl('relative_abundance', 
                                                    names(otus))][[1]],
                                                    abund_values = "relative_abundance") %>%
        subset_taxa(!is.na(Species))
    }, silent = T)
  }
  names <- names(list)
  list <- c(list,physeq)
  names(list) <- c(names,d)
}
#save(list,file = 'CRC_datasets.RData')

## For combining all of the 6 datasets listed into one 
#load(paste0("CRC_datasets.RData")) # saved list of phyloseq'd curated entries
physeq <- MergePhyseq('CRC',list)
table(sample_data(physeq)$dataset,
      sample_data(physeq)$study_condition)

## make a recipe
total_rec <- PhyseqToRecipe(physeq,'RANK')
y <- factor(as.numeric(total_rec$template$study_condition %in% c('CRC')))
dat <- total_rec %>%
  prep %>% 
  juice
dat$study_condition <- NULL
dat$y <- y
rec <- recipe(y ~ .,data = dat)
save(rec,file = 'microbiome_ranked.RData')
################################################################################
    ## MIMIC

## Uses MIMIC-III data set
## Take the 10th random split, shouldn't really matter
## data is kindly provided by the authors of SODEN, a novel survival network recently proposed
## https://arxiv.org/abs/2008.08637
dat <- foreach(
  file =
    list.files(
      'MIMIC Data/MIMIC Data/imputed-split-data/static'
    ),
  .combine = 'rbind'
) %do% {
  if (!grepl('_10', file)) {
    data.frame()
  } else {
    read.csv(
      paste0(
        'MIMIC Data/MIMIC Data/imputed-split-data/static/',
        file
      )
    )
  }
}
dat$y <- with(dat, Surv(time,
                        status))
dat$time <- NULL
dat$status <- NULL
rec <- recipe(y ~ .,
              data = dat) %>%
  role_case(stratum = 'y')

## for survival outcome
save(rec,
     file = "mimic.RData")

