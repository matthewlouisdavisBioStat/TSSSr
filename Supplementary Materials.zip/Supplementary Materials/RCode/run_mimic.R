
	## Run Empirical Results vs. RGS, PSO, and BO: MIMIC
set.seed(52245)
library(survival)
source('set_optim_thompson.R')
source('create_modspec.R')
datasets <- c(
  'mimic'
)
################################################################################
## functions for performing latin-grid sampling
sample_between_intervals <- function(x){
  intervals <- sort(unique(x))
  if(length(intervals) >= length(x)/2){
    x
  } else {
    sapply(x,function(y){
      ## if on the max, generate a uniform between a randomly-selected interval
      if (y == max(intervals)){
        s <- sample(1:(length(intervals)-1),1)
        runif(1,intervals[s],intervals[s+1])
        ## otherwise, generate uniform between obs and next interval
      } else {
        runif(1,y,min(intervals[intervals > y]))
      }
    })
  }
}
latin_grid <- function(grid){
  unq_g_1 <- apply(grid,2,function(x)length(unique(x)) > 1)
  numerics <- which(sapply(grid[1, ], class) == "numeric" & unq_g_1)
  for(num in c(numerics)){
    if(length(unique(unlist(grid[[num]]))) <= length(unlist(grid[[num]]))/4){
      grid[[num]] <- sample_between_intervals(as.numeric(unlist(grid[[num]])))
    }
  }
  return(grid)
}
################################################################################
## models here 
model_preps <- c(
  'XGBwKMModel_none'
)
################################################################################

## setup all of the parameters for simulations into a vector of strings
combos <- c(apply(
  expand.grid(
    model_preps,
    datasets
  ),
1,
paste0,collapse = "/"))
################################################################################

## Function for tuning 
run_tune_iteration <- function(modspec,
                               min_max = function(x)min(x),
                               plot_preds = F,
                               ...){
  #### #### #### ####
  ## Tuning for Optimizers
  #### #### #### #### 
  sys_strt <- Sys.time()
  fit_thompson <-
    fit(
      modspec %>% set_optim_thompson(
        times = 100,
        save_model_fit = F,
        plot_predicted_performance = F,
        save_model_fit_lable = paste0(seed,'_thompson.RData')
      )
    )
  thompson_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  fit_grid <-
    fit(modspec %>% set_optim_rgs(times = 100, random = 1))
  grid_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  length_bounds <- ncol(modspec@grid[[1]])
  fit_pso <- fit(modspec %>% set_optim_pso(times = ceiling(105/(floor(10 + 2 * sqrt(length_bounds)))),
                                           random = 1))
  pso_time <- (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  fit_bayes <-
    fit(modspec %>% set_optim_bayes(times = 100, 
                                    #times = 2,
                                    random = 1,
                                    #min_initial_points = ncol(modspec@grid[[1]]) + 1,
                                    packages = "rBayesianOptimization"))
  bayes_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  
  #### #### #### ####
  ## Organize Results
  #### #### #### ####
  points_thompson <- ((summary(as.MLModel(fit_thompson)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_grid <- ((summary(as.MLModel(fit_grid)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_pso <- ((summary(as.MLModel(fit_pso)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_bayes <- ((summary(as.MLModel(fit_bayes)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  #### #### #### ####
  
  #### #### #### ####
  df <- na.omit(data.frame(
    optimizer =c(rep('thompson',length(points_thompson)),
                 rep('grid',length(points_grid)),
                 rep('pso',length(points_pso)),
                 rep('bayes',length(points_bayes))),
    iteration = c(1:length(points_thompson),
                  1:length(points_grid),
                  1:length(points_pso),
                  1:length(points_bayes)),
    performance = c(
      points_thompson,
      points_grid,
      points_pso,
      points_bayes
    ),
    is_best = (c(
      points_thompson == min(points_thompson),
      points_grid == min(points_grid),
      points_pso == min(points_pso),
      points_bayes == min(points_bayes)
    ))
  ))
  
  #### #### #### #### 
  ## Summary Statistics
  #### #### #### #### 
  mean_perf <- df %>%
    group_by(optimizer) %>%
    summarize(
      "Mean Performance" = mean(performance),
      "Median Performance" = median(performance),
      "SD Performance" = sd(performance),
      "Best Performance" = min_max(performance)
    )
  
  performance_summary <- data.frame(optimizer = c('thompson', 
                                                  'grid', 
                                                  'pso', 
                                                  'bayes')) %>%
    mutate(
      "Tuning Time per Grid Point" = c(thompson_time,
                                       grid_time,
                                       pso_time,
                                       bayes_time) / c(
                                         length(points_thompson),
                                         length(points_grid),
                                         length(points_pso),
                                         length(points_bayes)
                                       )
    ) %>%
    mutate("Total Tuning Time" = c(thompson_time,
                                   grid_time,
                                   pso_time,
                                   bayes_time)) %>%
    right_join(mean_perf)
  
  #### #### #### #### 
  ## Out-of-Grid Performance
  #### #### #### ####
  params <- colnames(modspec@grid[[1]])
  outcome <- modspec@params@metrics
  
  
  ## if out-of-grid predictions are to be plotted
  if (plot_preds) {
    ## Load fitted beta coefficients and design matrix from thompson
    load(paste0(seed,'_thompson.RData'))
    ## the actual components
    colnames(design_mat)[grep('degree=1', colnames(design_mat))] <- c(params)
    # save observed grid performance that the thompson optimization DID NOT evaluate
    obs <-
      rbind(cbind(
        cbind((
          summary(as.MLModel(fit_grid))
        )[[1]]$params[[1]]),
        ((
          summary(as.MLModel(fit_grid))
        )[[1]]$metrics %>% unlist)) %>%
          colrename(c(params,
                      outcome))) %>%
      rbind(cbind(cbind((
        summary(as.MLModel(fit_pso))
      )[[1]]$params[[1]]),
      ((
        summary(as.MLModel(fit_pso))
      )[[1]]$metrics %>% unlist)) %>%
        colrename(c(params,
                    outcome))) %>%
      rbind(cbind(cbind((
        summary(as.MLModel(fit_bayes))
      )[[1]]$params[[1]]),
      ((
        summary(as.MLModel(fit_bayes))
      )[[1]]$metrics %>% unlist)) %>%
        colrename(c(params,
                    outcome)))
    
    ## bind out-of-grid predictions and observed cross-validated performance
    out_of_grid_predictions <-
      as(design_mat[-grid_points, ], 'matrix') %*% betaknot_new
    out_of_grid_params <-  (modspec@grid[[1]])[-grid_points, ]
    out_of_grid_params$prediction <- -out_of_grid_predictions
    plot_dat <- merge(obs, out_of_grid_params, by = params)
    
    #### #### #### ####
    ## Return Results
    #### #### #### ####
    return(
      list(
        points_thompson = points_thompson,
        points_grid = points_grid,
        points_pso = points_pso,
        points_bayes = points_bayes,
        performance_summary = performance_summary,
        params = params,
        outcome = outcome,
        plot_dat = plot_dat,
        seed = seed
      )
    )
  } else {
    return(
      list(
        points_thompson = points_thompson,
        points_grid = points_grid,
        points_pso = points_pso,
        points_bayes = points_bayes,
        performance_summary = performance_summary,
        params = params,
        outcome = outcome,
        seed = seed
      )
    )
  }
}
################################################################################
## Create the custom XGB model with k-means feature expansion
MOD <- function(k = 10,
                nrounds = 100,
                eta = 0.25,
                lambda = .1,
                alpha = .1,
                max_depth = 2,
                colsample_bytree = 0.5,
                subsample = 0.5,
                grow_policy = 'depthwise'){
  MLModel(
    name = "XGBwKMModel",
    response_types = c("BinomialVariate",
                       "factor", "matrix", "NegBinomialVariate", "numeric",
                       "PoissonVariate", "Surv"),
    weights = TRUE,
    params = list(
      'k' = k,
      'nrounds' = nrounds,
      'eta' = eta,
      'lambda' = lambda,
      'alpha' = alpha,
      'max_depth' = max_depth,
      'colsample_bytree' = colsample_bytree,
      'subsample' = subsample,
      'grow_policy' = grow_policy
    ),
    fit = function(formula, 
                   data, 
                   weights, 
                   k,
                   nrounds,
                   eta,
                   lambda,
                   alpha,
                   max_depth,
                   colsample_bytree,
                   subsample,
                   grow_policy,
                   ...) {
      data <- as.data.frame(data)
      data[,grepl('weights',colnames(data))] <- NULL
      data[,grepl('(names)',colnames(data))] <- NULL
      data[,grepl('strata.',colnames(data))] <- NULL
      print(head(data))
      recc <- step_kmeans((recipe(y ~ .,data[,!(colnames(data) %in% c('time',
                                                                      'status'))]) %>%
                             step_YeoJohnson(all_numeric_predictors()) %>%
                             step_normalize(all_numeric_predictors())),
                          all_numeric_predictors(),
                          k = k)
      juiced <- juice(prep(recc))
      new_formula <- as.formula(paste0(paste0("",'y',"",
                                              collapse = ""), 
                                       "~ .",
                                       collapse = " "))
      fitt <- MachineShop::fit(new_formula,
                               as.data.frame(bind_cols(juiced,
                                                       as.data.frame(
                                                         data[,!(colnames(data) %in% c('time',
                                                                                       'status',
                                                                                       'y'))]
                                                       )
                               )),
                               XGBTreeModel(
                                 nrounds = round(nrounds),
                                 max_depth = max_depth,
                                 alpha = alpha,
                                 lambda = lambda,
                                 eta = eta,
                                 colsample_bytree = colsample_bytree,
                                 subsample = subsample,
                                 grow_policy = grow_policy
                               ))
      return(list("recc" = recc,
                  "fitt" = fitt))
    },
    predict = function(object, newdata, ...) {
      
      recc <- object$recc
      fitt <- object$fitt
      newdata <- as.data.frame(newdata[,
                                       !(colnames(newdata) %in%
                                           c('time',
                                             'status'))])
      dat <- recc %>%
        prep %>%
        bake(new_data = newdata) %>%
        bind_cols(newdata) %>% 
        as.data.frame
      typ <- recc$template[ncol(recc$template)][[1]]
      if(length(unique(typ)) > 2){
        resptyp <- "numeric"
      } else {
        resptyp <- "prob"
      }
      if (nrow(dat) == 1) {
        MachineShop::predict(fitt, newdata = rbind(dat, dat),
                             type = resptyp)[1]
      } else {
        MachineShop::predict(fitt, newdata = dat, type = resptyp)
      }
    },
    varimp = function(object, ...) {
      NULL
    }
  )
}
XGBwKMModel <- MLModelFunction(MOD)
################################################################################
## last filtering/data prep
combos <- unique(combos)
print(combos)
cl <- makeCluster(12)
 registerDoParallel(cl)
load("mimic.RData")
dat <- rec %>%
  step_dummy(all_nominal_predictors()) %>%
  prep %>%
  juice %>%
  as.data.frame %>% 
  na.omit
dat$time <- as.numeric(dat$y)[1:nrow(dat)]
dat$status <- as.numeric(dat$y)[-c(1:nrow(dat))]
dat$y <- NULL
colnames(dat)[grepl('[.]',colnames(dat))] <- 
  sapply(colnames(dat)[grepl('[.]',colnames(dat))] ,
         function(x){
           paste0(unlist(strsplit(x,'[.]')),collapse = "_")
         })
dat$y <- with(dat,Surv(time,status))
dat$time <- NULL
dat$status <- NULL
## dummy fit so I can extract a recipe
tempfit <- fit(y ~ .,
               data = dat,
               model = XGBTreeModel)
## normalize predictors
rec <- as.MLInput(tempfit)
modspec <- ModelSpecification(rec,
                              model = TunedModel(XGBwKMModel,
                                                 grid = latin_grid(expand_params(
                                                   k = 2:50,
                                                   eta = seq(0.00001,0.9999, length.out = 3),
                                                   alpha = seq(0, 15,length.out = 3),
                                                   lambda = seq(0, 15, length.out = 3),
                                                   max_depth = 1:10,
                                                   colsample_bytree = seq(0.1,1,length.out = 3),
                                                   subsample = seq(0.1,1,length.out = 3),
                                                   nrounds = seq(100,2500,length.out = 3)+0.01, # so it can be recognized as numeric by xgb
                                                   grow_policy = c('depthwise', 'lossguide')
                                                 ))))
met <- 'cindex'
names(met) <- NULL
clusterExport(cl,unique(c(c(as.vector(lsf.str())),
                          ls(),
                          'MOD',
                          'XGBwKMModel',
                          'step_YeoJohnson',
                          'step_kmeans',
                          'step_normalize',
                          'recipe',
                          'prep',
                          'juice',
                          'bake',
                          'bind_cols',
                          'all_numeric_predictors')))

## run the empirical simulations
for(string in combos){
  
  ## extract simulation parameters from string code
  print(string)
  split_string <- unlist(strsplit(string,
                           "/"))
  split_first_split_string <- unlist(strsplit(split_string[1],
                                              "_"))
  
  ## run 10 repeats per circumstance
  print(paste0(paste0(split_string,collapse = ''),'.RData'))
    print("starting")
    run <- foreach(i = 1:24,.packages = c('doParallel',
                                          'recipes',
                                          'dplyr',
                                          'foreach',
                                          'MachineShop',
                                          'rBayesianOptimization',
                                          'pso',
                                          'survival',
                                          'kknn',
                                          'xgboost')) %dopar% {
                                           
      cl2 <- makeCluster(5)
      registerDoParallel(cl2)
      
      ## the seed is always the iteration number
      print(i)
      seed <- i
      set.seed(seed)
   

	    ## whether the metric is to be maximized or minimized
      met <- 'cindex'
      write.csv(paste0('run tune iteration ',string),file = 
                  paste0(i,'.csv'))
      clusterExport(cl2,unique(c(as.character(lsf.str()),
                                 'MOD',
                                 'XGBwKMModel',
                                 'step_YeoJohnson',
                                 'step_kmeans',
                                 'step_normalize',
                                 'recipe',
                                 'prep',
                                 'juice',
                                 'bake',
                                 'bind_cols',
                                 'all_numeric_predictors')))
      
      ## tune the model specification using each optimizer
       ret <- run_tune_iteration(modspec,
                          min_max = function(x)max(x))
      stopCluster(cl2)
      return(ret)
      
    }
    write.csv('save file',
              file = paste0(paste0(paste0(split_string,collapse = ''),
                                   '.csv')))

    ## save run 
    save(run,
         file = 
           paste0(paste0(split_string,collapse = ''),
                  '.RData'))

}
stopCluster(cl)




