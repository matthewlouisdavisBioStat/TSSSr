	## Getting the Best Results Using Stopping Rule: MIMIC
set.seed(52245)
library(survival)
source('set_optim_thompson.R')
source('create_modspec.R')
datasets <- c(
  'mimic'
)
################################################################################
## functions for performing latin-grid sampling
sample_between_intervals <- function(x){
  intervals <- sort(unique(x))
  if(length(intervals) >= length(x)/2){
    x
  } else {
    sapply(x,function(y){
      ## if on the max, generate a uniform between a randomly-selected interval
      if (y == max(intervals)){
        s <- sample(1:(length(intervals)-1),1)
        runif(1,intervals[s],intervals[s+1])
        ## otherwise, generate uniform between obs and next interval
      } else {
        runif(1,y,min(intervals[intervals > y]))
      }
    })
  }
}
latin_grid <- function(grid){
  unq_g_1 <- apply(grid,2,function(x)length(unique(x)) > 1)
  numerics <- which(sapply(grid[1, ], class) == "numeric" & unq_g_1)
  for(num in c(numerics)){
    if(length(unique(unlist(grid[[num]]))) <= length(unlist(grid[[num]]))/4){
      grid[[num]] <- sample_between_intervals(as.numeric(unlist(grid[[num]])))
    }
  }
  return(grid)
}
################################################################################
## models here 
model_preps <- c(
  'XGBwKMModel_none'
)
################################################################################

## setup all of the parameters for simulations into a vector of strings
combos <- c(apply(
  expand.grid(
    model_preps,
    datasets
  ),
1,
paste0,collapse = "/"))
################################################################################
## Create the custom XGB model with k-means feature expansion
MOD <- function(k = 10,
                nrounds = 100,
                eta = 0.25,
                lambda = .1,
                alpha = .1,
                max_depth = 2,
                colsample_bytree = 0.5,
                subsample = 0.5,
                grow_policy = 'depthwise'){
  MLModel(
    name = "XGBwKMModel",
    response_types = c("BinomialVariate",
                       "factor", "matrix", "NegBinomialVariate", "numeric",
                       "PoissonVariate", "Surv"),
    weights = TRUE,
    params = list(
      'k' = k,
      'nrounds' = nrounds,
      'eta' = eta,
      'lambda' = lambda,
      'alpha' = alpha,
      'max_depth' = max_depth,
      'colsample_bytree' = colsample_bytree,
      'subsample' = subsample,
      'grow_policy' = grow_policy
    ),
    fit = function(formula, 
                   data, 
                   weights, 
                   k,
                   nrounds,
                   eta,
                   lambda,
                   alpha,
                   max_depth,
                   colsample_bytree,
                   subsample,
                   grow_policy,
                   ...) {
      data <- as.data.frame(data)
      data[,grepl('weights',colnames(data))] <- NULL
      data[,grepl('(names)',colnames(data))] <- NULL
      data[,grepl('strata.',colnames(data))] <- NULL
      print(head(data))
      recc <- step_kmeans((recipe(y ~ .,data[,!(colnames(data) %in% c('time',
                                                                      'status'))]) %>%
                             step_YeoJohnson(all_numeric_predictors()) %>%
                             step_normalize(all_numeric_predictors())),
                          all_numeric_predictors(),
                          k = k)
      juiced <- juice(prep(recc))
      new_formula <- as.formula(paste0(paste0("",'y',"",
                                              collapse = ""), 
                                       "~ .",
                                       collapse = " "))
      fitt <- MachineShop::fit(new_formula,
                               as.data.frame(bind_cols(juiced,
                                                       as.data.frame(
                                                         data[,!(colnames(data) %in% c('time',
                                                                                       'status',
                                                                                       'y'))]
                                                       )
                               )),
                               XGBTreeModel(
                                 nrounds = round(nrounds),
                                 max_depth = max_depth,
                                 alpha = alpha,
                                 lambda = lambda,
                                 eta = eta,
                                 colsample_bytree = colsample_bytree,
                                 subsample = subsample,
                                 grow_policy = grow_policy
                               ))
      return(list("recc" = recc,
                  "fitt" = fitt))
    },
    predict = function(object, newdata, ...) {
      
      recc <- object$recc
      fitt <- object$fitt
      newdata <- as.data.frame(newdata[,
                                       !(colnames(newdata) %in%
                                           c('time',
                                             'status'))])
      dat <- recc %>%
        prep %>%
        bake(new_data = newdata) %>%
        bind_cols(newdata) %>% 
        as.data.frame
      typ <- recc$template[ncol(recc$template)][[1]]
      if(length(unique(typ)) > 2){
        resptyp <- "numeric"
      } else {
        resptyp <- "prob"
      }
      if (nrow(dat) == 1) {
        MachineShop::predict(fitt, newdata = rbind(dat, dat),
                             type = resptyp)[1]
      } else {
        MachineShop::predict(fitt, newdata = dat, type = resptyp)
      }
    },
    varimp = function(object, ...) {
      NULL
    }
  )
}
XGBwKMModel <- MLModelFunction(MOD)
################################################################################
## last filtering/data prep
combos <- unique(combos)
print(combos)
cl <- makeCluster(10)
 registerDoParallel(cl)
load("mimic.RData")
dat <- rec %>%
  step_dummy(all_nominal_predictors()) %>%
  prep %>%
  juice %>%
  as.data.frame %>% 
  na.omit
dat$time <- as.numeric(dat$y)[1:nrow(dat)]
dat$status <- as.numeric(dat$y)[-c(1:nrow(dat))]
dat$y <- NULL
colnames(dat)[grepl('[.]',colnames(dat))] <- 
  sapply(colnames(dat)[grepl('[.]',colnames(dat))] ,
         function(x){
           paste0(unlist(strsplit(x,'[.]')),collapse = "_")
         })
dat$y <- with(dat,Surv(time,status))
dat$time <- NULL
dat$status <- NULL
## dummy fit so I can extract a recipe
tempfit <- fit(y ~ .,
               data = dat,
               model = XGBTreeModel)
## normalize predictors
rec <- as.MLInput(tempfit)
modspec <- ModelSpecification(rec,
                              model = TunedModel(XGBwKMModel,
                                                 grid = latin_grid(expand_params(
                                                   k = 2:50,
                                                   eta = seq(0.00001,0.9999, length.out = 3),
                                                   alpha = seq(0, 15,length.out = 3),
                                                   lambda = seq(0, 15, length.out = 3),
                                                   max_depth = 1:10,
                                                   colsample_bytree = seq(0.1,1,length.out = 3),
                                                   subsample = seq(0.1,1,length.out = 3),
                                                   nrounds = seq(100,2500,length.out = 3)+0.01, # so it can be recognized as numeric by xgb
                                                   grow_policy = c('depthwise', 'lossguide')
                                                 ))))
met <- 'cindex'
names(met) <- NULL

## run the empirical simulations
for(string in combos){
  
  ## extract simulation parameters from string code
  print(string)
  split_string <- unlist(strsplit(string,
                           "/"))
  split_first_split_string <- unlist(strsplit(split_string[1],
                                              "_"))
  
  ## run 10 repeats per circumstance
  print(paste0(paste0(split_string,collapse = ''),'.RData'))
    print("starting")
    i <- 1
      
      ## the seed is always the iteration number
      print(i)
      seed <- i
      set.seed(seed)
   

	    ## whether the metric is to be maximized or minimized
      met <- 'cindex'
      write.csv(paste0('run tune iteration ',string),file = 
                  paste0(i,'_dissertation_mimic_1_best.csv'))
      clusterExport(cl,unique(c(as.character(lsf.str()),
                                 'MOD',
                                 'XGBwKMModel',
                                 'step_YeoJohnson',
                                 'step_kmeans',
                                 'step_normalize',
                                 'recipe',
                                 'prep',
                                 'juice',
                                 'bake',
                                 'bind_cols',
                                 'all_numeric_predictors')))
      
      strt_time <- Sys.time()
      final_fit <- modspec %>%
        set_optim_thompson(times = 250,
                           initial_points = 10,
                           stopping_rule_total = 25,
                           plot_predicted_performance = F) %>% 
        fit
      end_time <- Sys.time()
      final_dat <- list('summary' = summary(as.MLModel(final_fit)),
                        'start' = strt_time,
                        'end' = end_time)
      save(final_dat,file = paste0(paste0(split_string,
                                          collapse = ''),
                                   '_best.RData'))
      
}
stopCluster(cl)




