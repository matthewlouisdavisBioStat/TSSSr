	## Run Empirical Results vs. Adaptive Knots and GSS: AMES 
set.seed(52245)
source('set_optim_thompson.R')
source('create_modspec.R')

use_wahba <- T # are we comparing to traditional optimizers or Greedy Wahba?
if(use_wahba){
  source('set_optim_wahba.R')
}

## data sets
datasets <- c(
  'ames'
)
model_preps <- c(
  "GLMNetModel_none",
  "RFSRCModel_none",
  "XGBTreeModel_none"
)
################################################################################
## functions for performing latin-grid sampling
sample_between_intervals <- function(x){
  intervals <- sort(unique(x))
  if(length(intervals) >= length(x)/2){
    x
  } else {
    sapply(x,function(y){
      ## if on the max, generate a uniform between a randomly-selected interval
      if (y == max(intervals)){
        s <- sample(1:(length(intervals)-1),1)
        runif(1,intervals[s],intervals[s+1])
        ## otherwise, generate uniform between obs and next interval
      } else {
        runif(1,y,min(intervals[intervals > y]))
      }
    })
  }
}
latin_grid <- function(grid){
  unq_g_1 <- apply(grid,2,function(x)length(unique(x)) > 1)
  numerics <- which(sapply(grid[1, ], class) == "numeric" & unq_g_1)
  for(num in c(numerics)){
    if(length(unique(unlist(grid[[num]]))) <= length(unlist(grid[[num]]))/4){
      grid[[num]] <- sample_between_intervals(as.numeric(unlist(grid[[num]])))
    }
  }
  return(grid)
}
################################################################################
## tuning grids here
#tuning_grid_glmnet <- expand_params(
# alpha = seq(0,1,length.out = 250),
# lambda = seq(0,1,length.out = 250)
#)
 tuning_grid_glmnet <- expand_params(
   alpha = seq(0,1,length.out = 250),
   lambda = seq(0,2500^(0.25),length.out = 250)^4
 )
tuning_grid_rf <- latin_grid(expand_params(
  mtry = 2:250+0.01,
  ntree = as.integer(seq(50,2500,len = 100))+0.01,
  nodesize = 2:50 + 0.01,
  splitrule = c('logrank',
                'logrankscore',
                'bs.gradient',
                'gini',
                'auc',
                'entropy',
                'mse',
                'quantile.regr',
                'la.quantile.regr'
  )
))
tuning_grid_rf$mtry <- as.integer(round(tuning_grid_rf$mtry))
tuning_grid_rf$ntree <- as.integer(round(tuning_grid_rf$ntree))
tuning_grid_rf$nodesize <- as.integer(round(tuning_grid_rf$nodesize))


tuning_grid_xgbtree <-
  expand_params(
    eta = seq(0.00001,0.9999, length.out = 5),
    alpha = seq(0, 2,length.out = 5),
    lambda = seq(0, 2, length.out = 5),
    max_depth = 1:15,
    colsample_bytree = seq(0.1,1,length.out = 5),
    subsample = seq(0.1,1,length.out = 5),
    nrounds = seq(25,5000,length.out = 5)+0.01, # so it can be recognized as numeric by xgb
    grow_policy = c('depthwise', 'lossguide')
  )

################################################################################
## list of all tuning grids, latin grid'd if necessary
tuning_grids <- list(
  GLMNetModel = latin_grid(tuning_grid_glmnet),
  RFSRCModel = tuning_grid_rf,
  XGBTreeModel = latin_grid(tuning_grid_xgbtree)
)
## setup all of the parameters for simulations into a vector of strings
combos <- unique(
  c(apply(
    expand.grid(model_preps,
              datasets),
    1,
    paste0, collapse = "/"
)))
################################################################################
## Function for tuning 
run_tune_iteration <- function(modspec,
                               min_max = function(x)min(x),
                               ...){
  #### #### #### ####
  ## Optimizers
  #### #### #### #### 
  
  
  ## Thompson Sampling with Smoothing Splines
  sys_strt <- Sys.time()
  fit_thompson <- modspec %>% 
    set_optim_thompson(
        times = 100,
        save_model_fit = F,
        plot_predicted_performance = F,
        save_model_fit_lable = paste0(seed,'_thompson.RData')
      ) %>%
    fit
  thompson_time <-
    (Sys.time() - sys_strt) %>% 
    as.difftime(units = 'mins')
  
  ## RGS
  sys_strt <- Sys.time()
  fit_grid <- modspec %>%
    set_optim_rgs(times = 100, random = 1) %>%
    fit
  grid_time <-
    (Sys.time() - sys_strt) %>% 
    as.difftime(units = 'mins')
  
  ## PSO/Greedy Wahba
  sys_strt <- Sys.time()
  length_bounds <- ncol(modspec@grid[[1]])
  if(use_wahba){
    fit_pso <- modspec %>% 
        set_optim_thompson_wahba(
        times = 100,
        save_model_fit = F,
        plot_predicted_performance = F,
        save_model_fit_lable = paste0(seed,'_wahba.RData')
      ) %>%
      fit
  } else {
    fit_pso <- modspec %>% 
      set_optim_pso(times = 
                    ceiling(105/(floor(10 + 2 * sqrt(length_bounds)))),
                    random = 1) %>% 
      fit
  }
  pso_time <- (Sys.time() - sys_strt) %>% 
    as.difftime(units = 'mins')
  
  ## BO/Adaptive Knots
  sys_strt <- Sys.time()
  if(use_wahba){
    fit_bayes <- modspec %>% 
      set_optim_thompson(
          times = 100,
          cardinal_knots = F,
          save_model_fit = F,
          plot_predicted_performance = F,
          save_model_fit_lable = paste0(seed,'_thompson_ak.RData')
        ) %>%
      fit
      
  } else {
    fit_bayes <- modspec %>% 
        set_optim_bayes(times = 100,
                        random = 1,
                        packages = "rBayesianOptimization") %>%
        fit
  }
  bayes_time <-
    (Sys.time() - sys_strt) %>% 
    as.difftime(units = 'mins')
  
  #### #### #### ####
  ## Organize Results
  #### #### #### ####
  points_thompson <- ((summary(as.MLModel(fit_thompson)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_grid <- ((summary(as.MLModel(fit_grid)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_pso <- ((summary(as.MLModel(fit_pso)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_bayes <- ((summary(as.MLModel(fit_bayes)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  #### #### #### ####
  
  #### #### #### ####
  df <- na.omit(data.frame(
    optimizer =c(rep('thompson',length(points_thompson)),
                 rep('grid',length(points_grid)),
                 rep('pso',length(points_pso)),
                 rep('bayes',length(points_bayes))),
    iteration = c(1:length(points_thompson),
                  1:length(points_grid),
                  1:length(points_pso),
                  1:length(points_bayes)),
    performance = c(
      points_thompson,
      points_grid,
      points_pso,
      points_bayes
    ),
    is_best = (c(
      points_thompson == min(points_thompson),
      points_grid == min(points_grid),
      points_pso == min(points_pso),
      points_bayes == min(points_bayes)
    ))
  ))
  
  #### #### #### #### 
  ## summary statistics
  #### #### #### #### 
  mean_perf <- df %>%
    group_by(optimizer) %>%
    summarize(
      "Mean Performance" = mean(performance),
      "Median Performance" = median(performance),
      "SD Performance" = sd(performance),
      "Best Performance" = min_max(performance)
    )
  
  performance_summary <- data.frame(optimizer = c('thompson', 
                                                  'grid', 
                                                  'pso', 
                                                  'bayes')) %>%
    mutate(
      "Tuning Time per Grid Point" = c(thompson_time,
                                       grid_time,
                                       pso_time,
                                       bayes_time) / c(
                                         length(points_thompson),
                                         length(points_grid),
                                         length(points_pso),
                                         length(points_bayes)
                                       )
    ) %>%
    mutate("Total Tuning Time" = c(thompson_time,
                                   grid_time,
                                   pso_time,
                                   bayes_time)) %>%
    right_join(mean_perf)
  
  #### #### #### #### 
  ## return results
  #### #### #### ####
  params <- colnames(modspec@grid[[1]])
  outcome <- modspec@params@metrics
  
    return(
      list(
        points_thompson = points_thompson,
        points_grid = points_grid,
        points_pso = points_pso,
        points_bayes = points_bayes,
        performance_summary = performance_summary,
        params = params,
        outcome = outcome,
        seed = seed
      )
    )
  
}
################################################################################
print(combos)

## run the empirical simulations
cl <- makeCluster(12)
registerDoParallel(cl)
clusterExport(cl,unique(ls(),as.character(lsf.str())))
for(string in combos){
  
  ## extract simulation parameters from string code
  print(string)
  split_string <- unlist(strsplit(string,
                           "/"))
  split_first_split_string <- unlist(strsplit(split_string[1],
                                              "_"))
  
  ## run 24 repeats per circumstance
  print(paste0(paste0(split_string,collapse = ''),'.RData'))
  print("starting")
    run <- foreach(i = 1:24,.packages = c('doParallel',
                                          'recipes',
                                          'dplyr',
                                          'foreach',
                                          'MachineShop',
                                          'glmnet',
                                          'randomForestSRC',
                                          'kknn',
                                          'xgboost',
                                          'rBayesianOptimization',
                                          'nnet',
                                          'pso',
                                          'survival',
                                          'gss')) %dopar% {
                                            
      cl2 <- makeCluster(5)
      registerDoParallel(cl2)
      
      ## the seed is always the iteration number
      print(i)
      seed <- i
      set.seed(seed)

	    ## extract the metric of interest
      met <- unlist(sapply(split_string[2],
                           function(x){
                             if(x == 'microbiome_ranked') return('brier')
                             if(x == 'mnist_train') return('accuracy')
                             if(x == 'ames') return('rmse')
                             if(x == 'hnscc') return('cindex')
                             if(x == 'nba') return('mae')
                           })[1])[1]
      names(met) <- NULL
      print(met)

	    ## extract tuning grid
      tg <- tuning_grids[[split_first_split_string[1]]]

      ## correct splitrules per outcome type (for random forests)
      if(split_first_split_string[1] == 'RFSRCModel'){
        if(met == 'cindex'){
          tg <- tg[tg$splitrule %in% c(
            'logrank',
            'bs.gradient',
            'logrankscore'
          ),]
        } else if((met == 'brier') | (met == 'accuracy')){
          tg <- tg[tg$splitrule %in% c(
            'gini',
            'auc',
            'entropy'
          ),]
        } else if(met == 'rmse'){
          tg <- tg[tg$splitrule %in% c(
            'mse',
            'quantile.regr',
            'la.quantile.regr'
          ),]
        }
      }

      ## create a model specification object we are trying to tune
      modspec <- create_modspec(
        recipe = split_string[2],
        model = split_first_split_string[1],
        preprocess = paste0("step_",split_first_split_string[2]),
        metric = met,
        tuning_grid =
          tg
      )      

	    ## whether the metric is to be maximized or minimized
      min_max_func <- function(x)min(x)
      if(met == 'cindex'){
        min_max_func <- function(x)max(x)
      }
      write.csv(paste0('run tune iteration ',string),file = 
                  paste0(i,'_wahba.csv'))
	
      ## tune the model specification using each optimizer
      ret <- run_tune_iteration(modspec,
                         min_max = min_max_func)
      stopCluster(cl2)
      return(ret)
      
    }
    write.csv('save file',
              file = paste0(paste0(paste0(split_string,collapse = ''),
                                   '_wahba.csv')))

    ## save run 
    save(run,
         file = 
           paste0(paste0(split_string,collapse = ''),
                  '_wahba.RData'))

}
stopCluster(cl)




