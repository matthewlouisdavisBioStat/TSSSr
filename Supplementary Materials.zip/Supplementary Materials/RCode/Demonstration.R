## setup
library(MachineShop)
library(recipes)
library(doParallel)
setwd("Z:/Dissertation/ResultsForDefense/R Code")
#source("Z:/Dissertation/ResultsForDefense/set_optim_thompson_customplots.R")
#source("Z:/Dissertation/ResultsForDefense/set_optim_thompson.R")

# ## model housing prices in Iowa City using LASSO, tuning with grid search
# cl <- makeCluster(5)
# registerDoParallel(cl)
# ## fit it using random grid search
# fit <- 
#   recipe(sale_amount ~ .,data = ICHomes) %>%    # recipe
#   step_normalize(all_numeric_predictors()) %>%  # normalize predictors
#   ModelSpecification(model = TunedModel(        # model specification
#     GLMNetModel,                           # model
#     grid = expand_params(                  # tuning grid
#       lambda = seq(0,2500,len = 250000))), # candidate values
#     metrics = 'mse') %>%                      # metric
#   set_optim_grid(times = 250000) %>%           # optimizer
#   fit                                           # fit
# stopCluster(cl)
# save(fit,file = 'grid_search_evals.RData')
# s <- summary(as.MLModel(fit))
# save(s,file = 'grid_search_evals_summary.RData')


cl <- makeCluster(10)
registerDoParallel(cl)
layout(matrix(c(1,1,2,2,
                1,1,2,2,
                3,3,4,4,
                3,3,4,4,
                5,6,6,7,
                5,6,6,7),
              nrow = 6, 
              byrow = T))
load('C:/Users/defgi/Documents/grid_search_evals_summary.RData')
set.seed(52245)
fit <- 
      recipe(sale_amount ~ .,data = ICHomes) %>%    # recipe
      step_normalize(all_numeric_predictors()) %>%  # normalize predictors
      ModelSpecification(model = TunedModel(        # model specification
             GLMNetModel,                           # model
             grid = expand_params(                  # tuning grid
               alpha = seq(0,1,len = 100),
               lambda = seq(0,2500,len = 1000))),  # candidate values
           metrics = 'mse') %>%                     # metric
      set_optim_thompson(times = 36,degree = 9)  %>%           # optimizer
      fit                                           # fit
stopCluster(cl)
plot.new()
legend('bottomleft',
       col = c('black','green','red'),
       lty = c(1,1,0),
       pch = c(1,1,8),
       legend = c("Forecast",
                  "Observed",
                  "Evaluated"),
       bty = 'n')

## plotting what we actually evaluated 
s <- summary(as.MLModel(fit))
plot(s$TrainingStep1$params[[1]][[1]],
     -s$TrainingStep1$metrics[[1]],
     main = "All Grid Points Evaluated",
     xlab = "lambda",
     ylab = "-MSE")
#plot.new()


# Create a table
tab <- cbind(
                   c(10,15,25,35),
                   c(2618187852.52547,
                     2617653041.58774,
                     2617494239.40085,
                     2617494239.40085))
colnames(tab) <- c("Grid Points Evaluated (n)", "Best MSE so Far")
write.csv(tab,file = "five_panel_glmnet.csv",row.names = F)

# [1] "Best Observed: -2618187852.52547 || Best Prediction: -2589912197.5367"                             
# [1] "Best Observed: -2617653041.58774 || Best Prediction: -2617500783.84542"                            
# [1] "Best Observed: -2617494239.40085 || Best Prediction: -2618682710.81447"                            
# [1] "Best Observed: -2617494239.40085 || Best Prediction: -2618323694.65228"                            
###############################################################################

## SVM: Same Thing

# cl <- makeCluster(10)
# registerDoParallel(cl)
# layout(matrix(c(1,1,
#                 2,2,
#                 3,3,
#                 4,4),
#               byrow = T,
#               nrow = 4))
# fit <-
#   recipe(basement ~ ., data = ICHomes) %>%      # formula/data
#   step_dummy(all_nominal_predictors()) %>%      # convert categorical to indicators
#   step_normalize(all_numeric_predictors()) %>%  # normalize numeric predictors
#   ModelSpecification(model = TunedModel(        # model specification
#     SVMRadialModel,                             # model
#     grid = expand_params(                       # tuning grid
#       sigma = seq(0.1,10,len = 1000))),         # candidate values
#     metrics = 'kappa2') %>%                     # performance metric
#   fit                                           # fit
# stopCluster(cl)
# s <- summary(as.MLModel(fit))
#save(s,file = 'grid_search_evals_summary_svm.RData')

cl <- makeCluster(10)
registerDoParallel(cl)
layout(matrix(c(1,1,2,2,
                1,1,2,2,
                3,3,4,4,
                3,3,4,4,
                5,6,6,7,
                5,6,6,7),
              nrow = 6, 
              byrow = T))
load('grid_search_evals_summary_svm.RData')
set.seed(52245)
fit <-
  recipe(basement ~ ., data = ICHomes) %>%      # formula/data
  step_normalize(all_numeric_predictors()) %>%  # normalize numeric predictors
  ModelSpecification(model = TunedModel(        # model specification
    SVMRadialModel,                             # model
    grid = expand_params(                       # tuning grid
      sigma = seq(0.1,10,len = 10000))),        # candidate values
    metrics = 'kappa2') %>%                     # performance metric
    set_optim_thompson(times = 36) %>%          # optimizer
    fit                                         # fit
stopCluster(cl)
plot.new()
legend('bottomleft',
       col = c('black','green','red'),
       lty = c(1,1,0),
       pch = c(1,1,8),
       legend = c("Forecast",
                  "Observed",
                  "Evaluated"),
       bty = 'n')

## plotting what we actually evaluated 
s <- summary(as.MLModel(fit))
plot(s$TrainingStep1$params[[1]][[1]],
     s$TrainingStep1$metrics[[1]],
     main = "All Grid Points Evaluated",
     xlab = "sigma",
     ylab = "Kappa")




# Create a table
tab <- cbind(
  c(10,15,25,35),
  c(0.343643467580941,
    0.728612950107685,
    0.728612950107685,
    0.728799221575609))
colnames(tab) <- c("Grid Points Evaluated (n)", "Best Kappa so Far")
write.csv(tab,file = "five_panel_svm.csv",row.names = F)


# [1] "Best Observed: 0.343643467580941 || Best Prediction: 0.498536251656221"                               
# [1] "Best Observed: 0.728612950107685 || Best Prediction: 0.727806847946244"                               
# [1] "Best Observed: 0.728612950107685 || Best Prediction: 0.725333148186272"                               
# [1] "Best Observed: 0.728799221575609 || Best Prediction: 0.72421829854797" 
###############################################################################

## Pathological Simulation: Yup, same thing.


