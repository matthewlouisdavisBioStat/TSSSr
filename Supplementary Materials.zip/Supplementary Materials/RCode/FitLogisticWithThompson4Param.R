library(doParallel)
library(MachineShop)
library(recipes)
setwd('C:/Users/defgi/Documents')
source('set_optim_thompson_timed.R')
grid <- expand_params(
  b1 = seq(-1.5,1.5,len = 28),
  b2 = seq(-1.5,1.5,len = 28),  
  b3 = seq(-1.5,1.5,len = 28),
  b4 = seq(-1.5,1.5,len = 28)
)[1:500000,]
## latin grid-ish it
for(j in 1:ncol(grid)){
  grid[[j]] <- runif(length(grid[[j]]),
                     -1.5,
                     1.5)
}
TunedLogitModel <- function(b1 = 0,
                            b2 = 0,
                            b3 = 0,
                            b4 = 0){
  MLModel(
    name = "MyModel",
    response_types = "binary",
    weights = TRUE,
    params = list("b1" = b1,
                  "b2" = b2,
                  "b3" = b3,
                  "b4" = b4),
    fit = function(formula, data, weights, b1,b2,b3,b4,...) {
      return(list("coef" = c(b1,b2,b3,b4)))
    },
    predict = function(object, newdata, ...) {
      c(as.numeric(1/(1+exp(-as(newdata,'matrix') %*% c(object$coef) ))))
    },
    varimp = function(object, ...) {
      pchisq(coef(object)^2 / diag(vcov(object)), 1)
    }
  )
}
MyModel <- MLModelFunction(TunedLogitModel)

## use ICHomes data set as a dummy template
dat <- ICHomes[1:100,
                c('basement',
                  'sale_amount',
                  'bedrooms')]
dat$basement <- factor(as.numeric(dat$basement)-1)
dat[,-c(1)] <- apply(dat[,-c(1)],2,function(x)(x-mean(x))/sd(x))
dat$new_col1 <- rnorm(nrow(dat))
dat$new_col2 <- rbinom(nrow(dat),1,0.5)


## now, simulate outcome
set.seed(52245)
true_beta <- runif(4,-1,1)
print(true_beta)
dat$basement <- factor(rbinom(nrow(dat),
                              1,
                              1/(1+exp(- as(dat[,-1],'matrix') %*% 
                                         cbind(true_beta) ))))

## this is the true maximum likelihood estimate
true_mle <- fit(basement ~ 0 + sale_amount  +  bedrooms +
                  new_col1 +
                  new_col2, 
                data = dat,GLMModel)$coefficients
print(true_mle)

## model specification to fit - using train control and c.e. lf, 
## this is just fitting logistic regression with reinforcement
modspec <- ModelSpecification(input = recipe(basement ~ ., 
                 data = dat), 
                 model = TunedModel(MyModel,
                                    grid = grid,
                                    control = TrainControl(),
                                    metrics = "cross_entropy"),
                 metrics = "cross_entropy",
                 control = TrainControl())
f <- fit(modspec %>% set_optim_thompson(times = 1000,
                                        plot_predicted_performance = F,
                                        timer_name = 4))

## save and print
s <- summary(as.MLModel(f))
save(s,file = "computational_complexity_4.RData")