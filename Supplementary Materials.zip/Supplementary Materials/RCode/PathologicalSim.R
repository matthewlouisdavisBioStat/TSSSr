## libraries/functions
library(doParallel)
library(MachineShop)
library(recipes)
library(TSSSr)

## setup - simulate some sort of bimodal curve/data
set.seed(52245)
sharp_peak <- function(e,f,x){
  e*x + f*x^2
}
x <- seq(-10,24,len = 25000)
e <- -0.4515028
f <- -0.541947
y <- apply(cbind(sharp_peak(e = e, 
                            f = f, 
                            x = x),
                 sharp_peak(e = e + 100,
                            f = f - 55,
                            x = x-20)),
           1,
           max)
y <- y + rnorm(length(y),0,.1) # add very little, but not a lot of, noise

## plot the relationship between simulated -MAE (y) and tuning parameter (x)
y <- y-max(y)
plot(x,y,
     main = "Actual Relationship",
     xlab = "x",
     ylab = "-MAE")
x[which(y == max(y))]

## make a custom model to fit this curve
DummyModel <- function(x = 0){
  MLModel(
    name = "MyModel",
    response_types = "numeric",
    weights = TRUE,
    params = list("x" = x),
    fit = function(formula, data, weights, x,...) {
      return(list("x" = c(x)))
    },
    predict = function(object, newdata, ...) {
      apply(cbind(sharp_peak(e = e, 
                             f = f, 
                             x = x),
                  sharp_peak(e = e + 100,
                             f = f - 55,
                             x = x-20)),
            1,
            max) - 44.8429
    },
    varimp = function(object, ...) {
      NULL
    }
  )
}
MyModel <- MLModelFunction(DummyModel)


## tuning grid
grid <- expand_params(
  x = seq(-10,25,len = 50000)
)

## create modspec 
dat <- as.data.frame(cbind(0,rnorm(length(y))))
colnames(dat) <- c("y","z")
modspec <- ModelSpecification(input = recipe(y ~ ., 
                                             data = dat), 
                              model = TunedModel(MyModel,
                                                 grid = grid),
                              metrics = "mae",
                              control = TrainControl())


## fit it, default
fit <- fit(modspec %>% 
                    set_optim_thompson(times = 81))
s <- summary(as.MLModel(fit))

## fit it, enforcing positive definiteness
fit <- fit(modspec %>% 
                    set_optim_thompson(times = 81,
                    enforce_positive_definiteness = T))
s <- summary(as.MLModel(fit))

## fit it, with adaptive knots
fit <- fit(modspec %>% 
                    set_optim_thompson(times = 81,
                    cardinal_knots = F))
s <- summary(as.MLModel(fit))

