
## Setup
setwd("Z:/Dissertation/ResultsForDefense/Final Runs/")
library(MachineShop)
library(MASS)
df <- data.frame()

## read in data files and combine into a data frame
for(data_file in c(2,4,8)){
  final_dat <- read.csv(paste0('timer_',data_file,'.csv'))
  time <- as.numeric(final_dat[[1]]) # this is the time it took per each
  n <- 1:length(time) # how many grid points have been evaluated
  q <- data_file # raw number of variables
  p0 <- 1  + # one intercept
        q*3 + # one linear term, quadratic term, and cubic term,
        sum(q-c(1:(q-1))) # number of interactions
  temp <- data.frame(
    "Time" = time,
    "N" = n, # number of grid points evaluated
    "q" = q, # number of hyperparameters 
    "p0" = p0 # number of columns of design matrix for cubic regression
  )
  df <- rbind(df,temp)
}
df <- unique(na.omit(df))
write.csv(df, file = "Computational_Complexity.csv",row.names = F)




################################################################################

  ## evaluate empirical computational complexity

## predictors 
df$c <- (df$q^1.5 + 1)^2
df$n <- df$N
df$n2 <- df$N^2

## indices for 2-parameter, 4-parameter, and 8-parameter models
inds2 <- which(df$q == 2)
inds4 <- which(df$q == 4)
inds8 <- which(df$q == 8)

# outcome 
y <- df$Time

## bootstrap to obtain confidence intervals and point-estimates
set.seed(52245)
btsrp <- sapply(1:1000,function(m){

    # bootstrapped inds
    boot_inds <- sample(1:length(y),length(y),replace = T)

    # design matrix and associated components
    X <- cbind(1,
               df$c[boot_inds],
               df$n[boot_inds]
               )
    X %*% ginv(t(X) %*% X) %*% t(X) %*% log(y[boot_inds]-1)
})
mean(btsrp)
quantile(btsrp)
quantile(btsrp,c(0.005,0.995))
sd(btsrp)
# > mean(btsrp)
# [1] 2.883929
# > quantile(btsrp)
# 0%      25%      50%      75%     100% 
# 2.134649 2.527864 2.527905 3.472136 4.914855 
# > quantile(btsrp,c(0.005,0.995))
# 0.5%    99.5% 
#   2.156924 4.708499 
# > sd(btsrp)
# [1] 0.6133036

## box-cox with null nu
nu <- 2
df$n_nu <- (df$n^nu-1)/nu
model <- lm(log(Time) - 0.1 ~ 1 + c + n,data = df) %>%
  stepAIC(scope = list(upper = . ~ .,lower = . ~ c),
          direction = 'both')
AIC(model)
# [1] 62755.92 with intercept 
# [1] 62754.75 without intercept

## box-cox transform with chosen nu from bootstrapping
nu <- 2.883929
df$n_nu <- (df$n^nu-1)/nu
model <- lm(log(Time - 0.1) ~ 1 + log(c) + log(n) + c*n + c*n_nu,data = df) %>%
  stepAIC(scope = list(upper = . ~ .,lower = . ~ c),
          direction = 'both')
AIC(model)
# [1] 62631.39 with intercept
# [1] 62630.4 without intercept

print(summary(model))
(coef <- round(model$coefficients,5))
preds <- log(predict(model))
preds[is.nan(preds)] <- 0
resp <- log(df$Time-0.1)
layout(1)

## model fit
plot(preds,
     (resp),
     main = "Observed Log-Time vs. Fitted Values",
     ylab = "Observed Log-Time (Log-Seconds)",xlab = "Fitted Values")
abline(0,1)

## fitted values overlaid 
layout(t(matrix(c(1,1,1,1,
                1,1,1,1,
                2,2,2,2,
                2,2,2,2,
                3,3,3,3,
                3,3,3,3),
              nrow = 6,
              byrow = T)))
plot(df$Time[inds2],main = "2 Parameters",
     xlab = "",
     ylab = "Time Since Nth-1 Grid Point (Seconds)",
     cex.lab = 1.4,
     cex.main = 2,
     cex.axis = 1.2)
points(exp(preds[inds2]),col = 'blue')
plot(df$Time[inds4],main = "4 Parameters",
     xlab = "Nth Grid Point",
     ylab = "",
     cex.lab = 1.4,
     cex.main = 2,
     cex.axis = 1.2)
points(exp(preds[inds4]),col = 'blue')
plot(df$Time[inds8],main = "8 Parameters",
     xlab = "",
     ylab = "",
     cex.lab = 2,
     cex.main = 2,
     cex.axis = 1.2)
points(exp(preds[inds8]),col = 'blue')
legend('topright',c('Fitted','Observed'),col = c('blue','black'),pch = c(1,1),
       cex = 2)

