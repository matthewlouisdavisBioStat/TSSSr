
## Setup
library(MachineShop)
library(recipes)
library(foreach)
library(doParallel)
library(gss)

## fixed-iteration grid search
set_optim_rgs <- function(object,times,...) {
  set_optim_method(
    object,
    fun = function(optim, grid, ...) {
      for (i in sample(1:nrow(grid),min(times,nrow(grid)))) {
        optim(grid[i, ])
      }
      return(NULL)
    },
    label = "Random Grid Search",
    random = T
  )
}

## rename columns in-pipe
colrename <- function(x,names){
  colnames(x) <- names
  x
}

## Function for creating model specification objects
create_modspec <- function(recipe,
                           model,
                           preprocess,
                           metric,
                           tuning_grid,
                           use_split_control = F,
                           nfold = 10,
                           num_comp = 150){
  
  ## Load/ Data
  binary_vars <- NULL
  load(paste0(recipe, ".RData"))
  if(!is.null(binary_vars)){
    if(class(binary_vars[1]) == "numeric"){
      binary_vars <- names(binary_vars)
    } 
  }
  
  ## apply preprocessing step, if applicable
  if (preprocess == "step_normalize") {
    input <- rec %>%
      step_YeoJohnson(all_numeric_predictors()) %>% 
      step_normalize(all_numeric_predictors())
  } else if (preprocess == "step_kmeans") {
    input <- TunedInput(rec %>%
          step_YeoJohnson(all_numeric_predictors()) %>% 
          step_kmeans(all_numeric_predictors(), id = 'kmeans'),
                        grid = expand_steps(kmeans = list(k = as.integer(unique(round(
                          seq(2,500,
                              length.out = 100)
                        )))#,
                        #algorithm = c("Hartigan-Wong", "Lloyd", "Forgy", "MacQueen")
                        )),
                        metrics = metric
    )
  } else if (preprocess == "step_pca") {
    input <- TunedInput(
      rec %>%
        step_YeoJohnson(all_numeric_predictors()) %>% 
        step_normalize(all_numeric_predictors()) %>%
        step_pca(all_numeric_predictors(),id = 'pca'),
      grid = expand_steps(pca = list(num_comp = as.integer(unique(round(
        5:num_comp
      ))))),
      metrics = metric
    )
  } else {
    input <- rec
  }
  
  ## create model specification
  if(use_split_control){
    ModelSpecification(input = input,
                       model = TunedModel(
                         model,
                         grid = tuning_grid,
                         metrics = metric,
                         control = SplitControl()),
                       metrics = metric,
                       control = SplitControl())
  } else if(is.null(tuning_grid)){
    ModelSpecification(input = input,
                       model = model,
                       metrics = metric,
                       control = CVControl(folds = nfold))
  } else {
    ModelSpecification(input = input,
                       model = TunedModel(
                         model,
                         grid = tuning_grid,
                         metrics = metric),
                         metrics = metric,
                       control = CVControl(folds = nfold))
  }
}
