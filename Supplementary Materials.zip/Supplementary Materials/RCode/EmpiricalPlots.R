setwd("Z:/Dissertation/ResultsForDefense/Results")
library(dplyr)
adjust_ylim_ames <- F
adjust_ylim_hnscc_rf <- F
gg_color_hue <- function(n) {
  hues = seq(15, 375, length = n + 1)
  hcl(h = hues, l = 65, c = 100)[1:n]
}
colz <- gg_color_hue(4)
file_name <- paste('XGB_MICROBIOME')
wahba <- F
#save(run,file = '')


## for collecting best-performances at 100 grid points evaluated
# files <- paste0(apply(expand.grid(
#   c('GLMNET_','RF_','XGB_'),
#   c('HNSCC','AMES','MICROBIOME'),
#   c('','_wahba')
# ),1,paste,collapse = ""),'.csv')
# files <- c(files,'XGBwKM_MIMIC.csv','NNET_NBA.csv')
# master <- data.frame()
# for(file in files){
#   wahba <- grepl('wahba',file)
#   model <- unlist(strsplit(file,'_'))[[1]]
#   dataset <- unlist(strsplit(file,'_'))[[2]]
#   if(!wahba){
#     dataset <- unlist(strsplit(dataset,'.csv'))[[1]]
#   }
#   res <- read.csv(file)
#   res$model <- model
#   res$dataset <- dataset
#   res$wahba <- wahba
#   master <- rbind(master,res)
# }
# colnames(master) <- c(
#   'Optimizer',
#   'Mean Best-Performance (+/- SD)',
#   'Mean Total Time (+/- SD)',
#   'Model',
#   'Dataset',
#   'ComparedToWahba'
# )
# write.csv(master,file = 'BestAverageAt100.csv',row.names = F)

## XGBs
# load('XGBTreeModel_nonehnscc.RData')
# load('XGBTreeModel_noneames.RData')
load('XGBTreeModel_nonemicrobiome_ranked.RData')
# load('XGBTreeModel_nonehnscc_wahba.RData')
# load('XGBTreeModel_noneames_wahba.RData')
# load('XGBTreeModel_nonemicrobiome_ranked_wahba.RData')

## RFs
# load('RFSRCModel_nonehnscc.RData')
# load('RFSRCModel_noneames.RData')
# load('RFSRCModel_nonemicrobiome_ranked.RData')
#  load('RFSRCModel_nonehnscc_wahba.RData')
#load('RFSRCModel_noneames_wahba.RData')
# load('RFSRCModel_nonemicrobiome_ranked_wahba.RData')

## ENs
# load('GLMNetModel_nonehnscc.RData')
# load('GLMNetModel_noneames.RData')
# load('GLMNetModel_nonemicrobiome_ranked.RData')
# load('GLMNetModel_nonehnscc_wahba.RData')
# load('GLMNetModel_noneames_wahba.RData')
# load('GLMNetModel_nonemicrobiome_ranked_wahba.RData')

## Big Datasets
#load('XGBwKMModel_nonemimic.RData')
# load('NNetModel2_pcanba.RData')
# ## nba had pre-normalized outcome, which was 1/20th observed values
# for(i in 1:length(run)){
#   run[[i]]$points_thompson <- run[[i]]$points_thompson*20
#   run[[i]]$points_grid <- run[[i]]$points_grid*20
#   run[[i]]$points_pso <- run[[i]]$points_pso*20
#   run[[i]]$points_bayes <- run[[i]]$points_bayes*20
#   run[[i]]$performance_summary$`Best Performance` <-
#   run[[i]]$performance_summary$`Best Performance`*20
# }


metric_lab <- c('brier')
init_iterations <- 10
rem_inds <- which(unlist(lapply(run,function(i)length(i$points_bayes))) == 1)
#rem_inds <- which(unlist(lapply(run,function(i)length(i$points_pso))) == 1) # pso is wahba
if(length(rem_inds) > 0){
  run <- run[-rem_inds]
  print(rem_inds)
  Sys.sleep(2)
}
repeats <- length(run)
fix_names <- T
max_length <- 100
for(i in 1:repeats){
  run[[i]]$performance_summary$`Tuning Time per Grid Point` <- 
    as.numeric(run[[i]]$performance_summary$`Tuning Time per Grid Point`,
             units = 'secs')
  run[[i]]$performance_summary$`Total Tuning Time` <- 
    as.numeric(run[[i]]$performance_summary$`Total Tuning Time`,
             units = 'secs')
  names(run[[i]]$points_pso) <- paste0(metric_lab,1:length(run[[i]]$points_pso))
  if(fix_names){
    names(run[[i]]$points_thompson) <- 
      paste0(metric_lab,1:length(run[[i]]$points_thompson))
    names(run[[i]]$points_grid) <- 
      paste0(metric_lab,1:length(run[[i]]$points_grid))
    names(run[[i]]$points_pso) <- 
      paste0(metric_lab,1:length(run[[i]]$points_pso))
    names(run[[i]]$points_bayes) <- 
      paste0(metric_lab,1:length(run[[i]]$points_bayes))
  }
    
}
time_label <- "Seconds"
#time_label <- units(run[[1]]$performance_summary$`Total Tuning Time`)
# run <- run[-6]
################################################################################

library(MachineShop)
library(foreach)
library(ggpubr)

colrename <- function(x,y){
  colnames(x) <- y
  x
}
best_func <- function(x)min(x)
dir <- 'negative'
if(metric_lab == 'cindex' | metric_lab == "r2" | metric_lab == 'gini'){
  dir <- 'positive'
  best_func <- function(x)max(x)
}
time_function <- function(x,
                          obs_time = mean(sapply(1:repeats,function(i)run[[i]]$performance_summary$`Total Tuning Time`[1])),
                          init_iters = init_iterations,
                          grid_time = mean(sapply(1:repeats,function(i)run[[i]]$performance_summary$`Total Tuning Time`[2]))){
  n <- length(x)/repeats
  if(length(x) == 0){
    return(length(x))
  }
  avg_grid <- grid_time/n
  avg_obs <-  (obs_time - avg_grid*init_iters)/(n-init_iters) 
  x_temp <- x
  for(k in 1:repeats){
    xx <- x[(k-1)*n + 1:n]
    xx[1:init_iters] <- avg_grid*(1:init_iters)
    xx[-c(1:init_iters)] <- x[init_iters] + avg_obs * (1:(n - init_iters))
    x_temp[(k-1)*n + 1:n] <- xx
  }
  return(x_temp)
}
overlaid <- foreach(iter = c(1:repeats),.combine = 'cbind') %do% {
  print(iter)
  sap <- t(sapply(c('points_thompson','points_bayes','points_pso','points_grid'),function(method){
    unl <- unlist(run[[iter]][[method]])
    if(length(unl) < max_length){
      all_names <- paste0(metric_lab,1:max_length)
      unl <- sapply(all_names,function(nm){
        if(nm %in% names(unl)) unl[nm] else NA
      })
      #unl <- c(unl, rep(NA,max_length - length(unl)))
      names(unl) <- paste0(metric_lab,1:length(unl))
    } else if (length(unl) >= max_length){
      unl <- unl[1:max_length]
    }
    unl
  }))
}
rows <- 1:4
metrics <- foreach(k = rows,.combine = 'c') %do% {
  overlaid[k,]
}
iters <- as.numeric(substr(names(metrics),nchar(metric_lab)+1,nchar(names(metrics))))
methods <- rep(rownames(overlaid[rows,]),each = ncol(overlaid[rows,]))
plot_dat <- data.frame(
  metrics,
  iters,
  methods
)
for(method in c('points_thompson',
                'points_pso',
                'points_bayes')){
  print(method)
  if(method == 'points_bayes'){
    init <- 5
  } else if(method == 'points_pso'){
    init <- 1
  } else {
    init <- init_iterations
  }
  plot_dat[plot_dat$methods == method,'time'] <- time_function(
    plot_dat[plot_dat$methods == method,'time'],
    obs_time = mean(sapply(1:repeats,function(i)run[[i]]$performance_summary$`Total Tuning Time`[which(paste0("points_",run[[1]]$performance_summary$optimizer) == method)])),
    init_iters = init)
} 
plot_dat2 <-   plot_dat %>%
  group_by(iters,methods) %>%
  summarize(
    median_metrics = median(metrics,na.rm = F),
    mean_metrics = mean(metrics,na.rm = F),
    iqr_up = quantile(metrics,0.75,na.rm = F),
    iqr_down = quantile(metrics,0.25,na.rm = F),
    sd = sd(metrics,na.rm = F)) %>%
  mutate(sd_up = mean_metrics + sd/sqrt(repeats),
         sd_down = mean_metrics - sd/sqrt(repeats))
plot_dat2$Methods <- toupper(substr(plot_dat2$methods,
                                    nchar('points_') + 1,
                                    nchar(plot_dat2$methods)))
colorz <- sapply(plot_dat2$methods,
                 function(m){
                   if(m == "points_thompson") return(colz[4])
                   if(m == "points_grid") return(colz[2])
                   if(m == "points_bayes") return(colz[1])
                   if(m == "points_pso") return(colz[3])
                 })
plot_dat$Methods <- toupper(substr(plot_dat$methods,
                                   nchar('points_') + 1,
                                   nchar(plot_dat$methods)))

## fix labels
if(wahba){
  plot_dat$Methods[plot_dat$Methods == "BAYES"] <- "TSSS A.K."
  plot_dat$Methods[plot_dat$Methods == "PSO"] <- "WAHBA"
  plot_dat$Methods[plot_dat$Methods == "GRID"] <- "RGS"
  plot_dat$Methods[plot_dat$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "TSSS A.K.") return(colz[1])
                     if(m == "WAHBA") return(colz[3])
                   })
} else {
  plot_dat$Methods[plot_dat$Methods == "BAYES"] <- "BO"
  plot_dat$Methods[plot_dat$Methods == "PSO"] <- "PSO"
  plot_dat$Methods[plot_dat$Methods == "GRID"] <- "RGS"
  plot_dat$Methods[plot_dat$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "BO") return(colz[1])
                     if(m == "PSO") return(colz[3])
                   })
}

## instantaneous performance per grid point
gg1 <- ggplot(data = plot_dat,mapping = aes(x = iters, 
                                            y = metrics, 
                                            col = Methods,
                                            fill = Methods)) +
  geom_smooth() +
  labs(title = "Average Instantaneous Performance vs. # Grid Points Evaluated",
       y = paste0("Observed ", metric_lab),
       x = "# Grid Points Evaluated") +
       geom_vline(xintercept = init_iterations) +
       theme(text = element_text(size = 20)) 
if(wahba){
  gg1 <- gg1 + 
    scale_fill_manual(values = colorz)  +
    scale_color_manual(values = colorz)
} 
# png(file = paste0(file_name,'_instant_final.png'),
#     height=500, 
#     width=round(0.5*(1+sqrt(5))*600))
#gg1
#dev.off()

## repeat, but with time as the x-axis
best_perf <- apply(sapply(1:length(run), function(i) {
  as.numeric(run[[i]]$performance_summary$`Best Performance`)
}), 1, best_func)
summary_stats <-  cbind(run[[1]]$performance_summary$optimizer,
                        Reduce("+", lapply(run, function(x){
                          z <- x[['performance_summary']][, -1]
                          z[is.na(z)] <- 0
                          z})) / repeats,
                        best_perf
) %>%
  dplyr::select(
    c(
      "run[[1]]$performance_summary$optimizer",
      "Median Performance",
      "SD Performance",
      "Best Performance",
      "Total Tuning Time",
    )
  ) %>%
  colrename(c(
    "Optimizer",
    "Avg. Median",
    "Avg. SD",
    "Avg. Best",
    "Avg. Time"
  ))
plot_dat$time <- sapply(plot_dat$methods,function(x)summary_stats$`Avg. Time`[
  paste0("points_",summary_stats$Optimizer) == x])*
  plot_dat$iters/max(plot_dat$iters)


## again, instantaneous performance w.r.t. time - this isn't really necessary,
## and will not be pertinent to final results
gg2 <- ggplot(data = plot_dat,mapping = aes(x = time, y = metrics, col = methods)) +
  geom_smooth(n = 100) + 
  #geom_jitter(alpha = 0.25, size = 0.25) + 
  labs(title = "Observed Performance vs. Time",
       y = paste0("Observed ", metric_lab),
       x = paste0("Time (",time_label,")")) +
  geom_vline(xintercept = mean(plot_dat$time[plot_dat$methods == 'points_thompson' &
                                               plot_dat$iters == init_iterations]))


## repeat, but with accumulation
best_so_far <- function(x,dir){
  nms <- names(x)
  if(dir == 'negative'){
    best <- Inf
    best_vec <- rep(best,length(x))
    for(j in 1:length(x)){
      if(best > x[j]){
        best <- x[j]
        best_vec[-c(1:j)] <- best
      }
    }
    best_vec[1] <- x[1]
  } else {
    best <- -Inf
    best_vec <- rep(best,length(x))
    for(j in 1:length(x)){
      if(best <=  x[j]){
        best <- x[j]
        best_vec[-c(1:j)] <- best
      }
    }
    best_vec[1] <- x[1]
  }
  names(best_vec) <- nms
  best_vec
}
run_accum <- lapply(run,function(r){
  r$points_thompson <- best_so_far(r$points_thompson,dir)
  r$points_pso <- best_so_far(r$points_pso,dir)
    r$points_grid <- best_so_far(r$points_grid,dir)
  r$points_bayes <- best_so_far(r$points_bayes,dir)
  r
})
################################################################################
overlaid <- foreach(iter = c(1:repeats),.combine = 'cbind') %do% {
  print(iter)
  sap <- t(sapply(c('points_thompson','points_bayes','points_pso','points_grid'),function(method){
    unl <- unlist(run_accum[[iter]][[method]])
    if(length(unl) < max_length){
      all_names <- paste0(metric_lab,1:max_length)
      unl <- sapply(all_names,function(nm){
        if(nm %in% names(unl)) unl[nm] else NA
      })
      #unl <- c(unl, rep(NA,max_length - length(unl)))
     } else if (length(unl) >= max_length){
      unl <- unl[1:max_length]
    }
    unl
  }))
}
metrics <- foreach(k = rows,.combine = 'c') %do% {
  overlaid[k,]
}
iters <- as.numeric(substr(names(metrics),nchar(metric_lab)+1,nchar(names(metrics))))
methods <- rep(rownames(overlaid[rows,]),each = ncol(overlaid[rows,]))
plot_dat <- data.frame(
  metrics,
  iters,
  methods
)
plot_dat2 <-   plot_dat %>%
  group_by(iters,methods) %>%
  summarize(#time = mean(time),
            median_metrics = median(metrics,na.rm = F),
            mean_metrics = mean(metrics,na.rm = F),
            iqr_up = quantile(metrics,0.75,na.rm = F),
            iqr_down = quantile(metrics,0.25, na.rm = F),
            sd = sd(metrics,na.rm = F)) %>%
  mutate(sd_up = mean_metrics + sd/sqrt(repeats),
         sd_down = mean_metrics - sd/sqrt(repeats))
colorz <- sapply(plot_dat2$methods,
                 function(m){
                   if(m == "points_thompson") return(colz[4])
                   if(m == "points_grid") return(colz[2])
                   if(m == "points_bayes") return(colz[1])
                   if(m == "points_pso") return(colz[3])
                 })
plot_dat2$Methods <- toupper(substr(plot_dat2$methods,
                                    nchar('points_') + 1,
                                    nchar(plot_dat2$methods)))
## fix wahba labels
if(wahba){
  plot_dat2$Methods[plot_dat2$Methods == "BAYES"] <- "TSSS A.K."
  plot_dat2$Methods[plot_dat2$Methods == "PSO"] <- "WAHBA"
  plot_dat2$Methods[plot_dat2$Methods == "GRID"] <- "RGS"
  plot_dat2$Methods[plot_dat2$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat2$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "TSSS A.K.") return(colz[1])
                     if(m == "WAHBA") return(colz[3])
                   })
  names(colorz)[names(colorz) == "BAYES"] <- "TSSS A.K."
  names(colorz)[names(colorz) == "PSO"] <- "WAHBA"
  names(colorz)[names(colorz) == "GRID"] <- "RGS"
  names(colorz)[names(colorz) == "THOMPSON"] <- "TSSS"
  
} else {
  plot_dat2$Methods[plot_dat2$Methods == "BAYES"] <- "BO"
  plot_dat2$Methods[plot_dat2$Methods == "PSO"] <- "PSO"
  plot_dat2$Methods[plot_dat2$Methods == "GRID"] <- "RGS"
  plot_dat2$Methods[plot_dat2$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat2$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "BO") return(colz[1])
                     if(m == "PSO") return(colz[3])
                   })
  names(colorz)[names(colorz) == "BAYES"] <- "BO"
  names(colorz)[names(colorz) == "PSO"] <- "PSO"
  names(colorz)[names(colorz) == "GRID"] <- "RGS"
  names(colorz)[names(colorz) == "THOMPSON"] <- "TSSS"
}


gg3 <- ggplot(data = plot_dat2,
              mapping = aes(x = iters,
                            y = mean_metrics, 
                            col = methods,
                            fill = methods)) +
  geom_step(size = 1.5) + 
  labs(title = "Mean Cumulative Performance vs. # Grid Points",
       y = paste0("Best observed ", metric_lab),
       x = "Number of Grid Points Evaluated Thus Far") +
  geom_vline(xintercept = init_iterations)
if(wahba){
  plot_dat2$Methods <- factor(plot_dat2$Methods,
                              levels = c('TSSS A.K.',
                                         'RGS',
                                         'WAHBA',
                                         'TSSS'))
} else {
  plot_dat2$Methods <- factor(plot_dat2$Methods,
                              levels = c('BO',
                                         'RGS',
                                         'PSO',
                                         'TSSS'))
}
gg3_mean <- ggplot(data = plot_dat2,
                   mapping = aes(x = iters, 
                                 y = mean_metrics,
                                 col = Methods,
                                 fill = Methods))  +
  geom_step(size = 1.5) + 
  geom_rect(xmin = plot_dat2$iters - 1,
            xmax = plot_dat2$iters,
            ymin = plot_dat2$sd_down,
            ymax = plot_dat2$sd_up,
            col = colorz,
            alpha = 0.05)  + 
  labs(title = "Mean +/- SE Cumulative Performance vs. # Grid Points",
       y = paste0("Best observed ", metric_lab),
       x = "Number of Grid Points Evaluated Thus Far") +
  geom_vline(xintercept = init_iterations)
if(wahba){
  gg3_mean <- gg3_mean +  
    scale_fill_manual(values = colorz) + 
    scale_colour_manual(values = colorz) 
} 


## for adjusting metric-y axis range 
if(adjust_ylim_ames){
  gg3 <- gg3 +  ylim(c(25000,35000))
  gg3_mean <- gg3_mean +  ylim(c(25000,35000))
}
if(adjust_ylim_hnscc_rf){
  gg3 <- gg3 + ylim(c(0.775,0.8))
  gg3_mean <- gg3_mean  + ylim(c(0.775,0.8))
}

## repeat, but with time as the x-axis
best_perf <- apply(sapply(1:length(run_accum), function(i) {
  as.numeric(run_accum[[i]]$performance_summary$`Best Performance`)
}), 1, best_func)
summary_stats <-  cbind(run_accum[[1]]$performance_summary$optimizer,
                        Reduce("+", lapply(run_accum, function(x){
                          z <- x[['performance_summary']][, -1]
                          z[is.na(z)] <- 0
                          z})) / repeats,
                        best_perf
) %>%
  dplyr::select(
    c(
      "run_accum[[1]]$performance_summary$optimizer",
      "Median Performance",
      "SD Performance",
      "Best Performance",
      "Total Tuning Time",
    )
  ) %>%
  colrename(c(
    "Optimizer",
    "Avg. Median",
    "Avg. SD",
    "Avg. Best",
    "Avg. Time"
  ))
plot_dat$time <- sapply(plot_dat$methods,function(x)summary_stats$`Avg. Time`[paste0("points_",summary_stats$Optimizer) == x])*plot_dat$iters/max(plot_dat$iters)
og_time <- plot_dat %>% group_by(methods) %>% summarize(max_time = max(time))
for(timez in unique(plot_dat$time)){
  for(methodz in unique(plot_dat$methods)){
    if(nrow(plot_dat[plot_dat$time == timez & plot_dat$method == methodz,]) == 0){
      max_timez <- max(plot_dat$time[plot_dat$time < timez & 
                                     plot_dat$methods == methodz])
      if(max_timez == -Inf){
        max_timez <- min(plot_dat$time[plot_dat$methods == methodz])
      }
      dummy <- plot_dat[plot_dat$time == max_timez & plot_dat$method == methodz,]
      dummy$time <- timez
      plot_dat <- rbind(plot_dat,dummy)
    }
  }
}

plot_dat2 <-   plot_dat %>%
  group_by(time,methods,iters) %>%
  summarize(median_metrics = median(metrics,na.rm = F),
            mean_metrics = mean(metrics,na.rm = F),
            iqr_up = quantile(metrics,0.75,na.rm = F),
            iqr_down = quantile(metrics,0.25, na.rm = F),
            sae = mean(abs(metrics - median(metrics,na.rm = F))),
            sd = sd(metrics,na.rm = F)) %>%
  na.omit %>%
  unique %>%
  mutate(sd_up = mean_metrics + sd/sqrt(repeats),
         sd_down = mean_metrics - sd/sqrt(repeats))
plot_dat2$time_down <- sapply(plot_dat2$time,
                              function(timez){
                                unq <- unique(plot_dat2$time[plot_dat2$time < timez])
                                if(length(unq) == 0){
                                  return(timez)
                                } else {
                                  max(unq)
                                }
                              })
plot_dat2$colorz <- sapply(plot_dat2$methods,
                 function(m){
                   if(m == "points_thompson") return(colz[4])
                   if(m == "points_grid") return(colz[2])
                   if(m == "points_bayes") return(colz[1])
                   if(m == "points_pso") return(colz[3])
                 })
plot_dat2$mean_diff <- mean(plot_dat2$time-
                            plot_dat2$time_down)
for(met in unique(plot_dat2$methods)){
  wch <- which(plot_dat2$methods == met &  
                 plot_dat2$time > og_time$max_time[og_time$methods == met])
  if(length(wch) > 0){
    plot_dat2 <- plot_dat2[-wch,]
  }
}
plot_dat2$Methods <- toupper(substr(plot_dat2$methods,
                            nchar('points_') + 1,
                            nchar(plot_dat2$methods)))
## fix wahba labels
if(wahba){
  plot_dat2$Methods[plot_dat2$Methods == "BAYES"] <- "TSSS A.K."
  plot_dat2$Methods[plot_dat2$Methods == "PSO"] <- "WAHBA"
  plot_dat2$Methods[plot_dat2$Methods == "GRID"] <- "RGS"
  plot_dat2$Methods[plot_dat2$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat2$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "TSSS A.K.") return(colz[1])
                     if(m == "WAHBA") return(colz[3])
                   })
  names(colorz)[names(colorz) == "BAYES"] <- "TSSS A.K."
  names(colorz)[names(colorz) == "PSO"] <- "WAHBA"
  names(colorz)[names(colorz) == "GRID"] <- "RGS"
  names(colorz)[names(colorz) == "THOMPSON"] <- "TSSS"
} else {
  plot_dat2$Methods[plot_dat2$Methods == "BAYES"] <- "BO"
  plot_dat2$Methods[plot_dat2$Methods == "PSO"] <- "PSO"
  plot_dat2$Methods[plot_dat2$Methods == "GRID"] <- "RGS"
  plot_dat2$Methods[plot_dat2$Methods == "THOMPSON"] <- "TSSS"
  colorz <- sapply(plot_dat2$Methods,
                   function(m){
                     if(m == "TSSS") return(colz[4])
                     if(m == "RGS") return(colz[2])
                     if(m == "BO") return(colz[1])
                     if(m == "PSO") return(colz[3])
                   })
  names(colorz)[names(colorz) == "BAYES"] <- "BO"
  names(colorz)[names(colorz) == "PSO"] <- "PSO"
  names(colorz)[names(colorz) == "GRID"] <- "RGS"
  names(colorz)[names(colorz) == "THOMPSON"] <- "TSSS"
}

gg4 <- ggplot(data = plot_dat2,
              mapping = aes(x = time, 
                            y = mean_metrics, 
                            col = methods)) +
  geom_step(size = 1.5) + 
  labs(title = "Mean Cumulative Performance vs. Time",
       y = paste0("Best observed ", metric_lab),
       x = paste0("Time (",time_label,")")) +
  geom_vline(xintercept = mean(plot_dat$time[plot_dat$methods == 'points_thompson' &
                                               plot_dat$iters == init_iterations]))
if(wahba){
  plot_dat2$Methods <- factor(plot_dat2$Methods,
                              levels = c('TSSS A.K.',
                                         'RGS',
                                         'WAHBA',
                                         'TSSS'))
} else {
  plot_dat2$Methods <- factor(plot_dat2$Methods,
                              levels = c('BO',
                                         'RGS',
                                         'PSO',
                                         'TSSS'))
}
gg4_mean <- ggplot(data = plot_dat2,mapping = aes(x = time, 
                                                    y = mean_metrics,
                                                    col = Methods,
                                                    fill = Methods)) +
  geom_step(size = 1.5) +
  geom_rect(xmin = c(0,plot_dat2$time[-(length(plot_dat2$time))]),
            xmax = plot_dat2$time,
            ymin = plot_dat2$sd_down,
            ymax = plot_dat2$sd_up,
            col = plot_dat2$colorz,
            alpha = 0.05)  + 
  labs(title = "Mean +/- SE Cumulative Performance vs. Time",
       y = paste0("Best observed ", metric_lab),
       x = paste0("Time (",time_label,")")) +
  geom_vline(xintercept = median(plot_dat$time[plot_dat$methods == 'points_thompson' &
                                               plot_dat$iters == init_iterations]))
if(wahba){
  gg4_mean <- gg4_mean +  
    scale_fill_manual(values = colorz) + 
    scale_colour_manual(values = colorz) 
}
if(adjust_ylim_ames){
  gg4 <- gg4 + ylim(c(25000,35000))
  gg4_mean <- gg4_mean + ylim(c(25000,35000))
}
if(adjust_ylim_hnscc_rf){
  gg4 <- gg4 + ylim(c(0.775,0.8))
  gg4_mean <- gg4_mean  + ylim(c(0.775,0.8))
}


png(file = paste0(file_name,'_final.png'),
    height= 900, width=round(0.5*(1+sqrt(5))*500))
gg <- ggarrange(
       gg3_mean + theme(text = element_text(size = 20)),
       gg4_mean + theme(text = element_text(size = 20)),
  ncol = 1,
  nrow = 2,
  common.legend = T,
  font.label = list(size = 25, color = "black", face = "bold", family = NULL)
  
) 
gg
save(gg,file = paste0(file_name,'_final.RData'))
dev.off()


# overall totals
ot <- cbind(run[[1]]$performance_summary[,1],
      Reduce("+",lapply(run,function(i)i$performance_summary[,-1]))/length(run))

## average best performance
all_means <- sapply(run[-2],function(x)x$performance_summary[,7])
medians <- apply(all_means,1,median)
colnames(ot)[1] <- "Optimizer"
meann_sd <- function(x,r = 3)paste0(round(mean(x,na.rm = F),r),
                              " (+/- ",
                              round(sd(x,na.rm = F),r),
                              ")")

## clean a csv for formatting/comparing final performance
presentation <- data.frame(
  Method = c("TSSS",
             "RGS",
             "PSO",
             "BO"),
  "Mean Best" = apply(all_means,1,meann_sd),
  "Mean Total Time" = apply(sapply(run,function(x)x$performance_summary$`Total Tuning Time`),
                            1,
                            meann_sd,
                            0
  )
)
colnames(presentation) <- 
  c(
    "Method",
    "Mean Best Performance (+/- SD)",
    "Mean Total Time (+/- SD)"
  )
print(presentation)
if(wahba){
  presentation$Method <- c(
    "TSSS",
    "RGS",
    "Wahba",
    "TSSS A.K."
  )
}
# write.csv(presentation,
#           file = paste0(file_name,'.csv'),
#           row.names = F)

