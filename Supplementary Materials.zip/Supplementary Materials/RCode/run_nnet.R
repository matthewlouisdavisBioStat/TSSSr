## Run Empirical Results vs. RGS, PSO, and BO: NBA
set.seed(52245)
source('set_optim_thompson.R')
source('create_modspec.R')
datasets <- c(
  'nba'
)
NNetModel2 <- NNetModel(maxit = 1000,
                        MaxNWts = 10000000)
################################################################################
## models here 
model_preps <- c(
  "NNetModel2_pca"
)
#######################################
## tuning grids here
tuning_grid_nnet <- expand_params(
  decay = seq(0,5,length.out = 250)^4,
  size = 2:25
)
#######################################

## list of all tuning grids
tuning_grids <- list(
  NNetModel2 = tuning_grid_nnet
)

################################################################################

## setup all of the parameters for simulations into a vector of strings
combos <- c(apply(
  expand.grid(
    model_preps,
    datasets
  ),
  1,
  paste0,collapse = "/"))
# combos <- c(combos,'SurvRegModel_kmeans/HNSCC') # add in SurvRegModel
################################################################################

## Function for tuning 
run_tune_iteration <- function(modspec,
                               min_max = function(x)min(x),
                               plot_preds = F,
                               ...){
  #### #### #### ####
  ## Tuning for Optimizers
  #### #### #### #### 
  sys_strt <- Sys.time()
  fit_thompson <-
    fit(
      modspec %>% set_optim_thompson(
        times = 100,
        save_model_fit = F,
        plot_predicted_performance = F,
        save_model_fit_lable = paste0(seed,'_thompson.RData')
      )
    )
  thompson_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  fit_grid <-
    fit(modspec %>% set_optim_rgs(times = 100, random = 1))
  grid_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  length_bounds <- ncol(modspec@grid[[1]])
  fit_pso <- fit(modspec %>% set_optim_pso(times = ceiling(105/(floor(10 + 2 * sqrt(length_bounds)))),
                                           random = 1))
  pso_time <- (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  sys_strt <- Sys.time()
  fit_bayes <-
    fit(modspec %>% set_optim_bayes(times = 100, 
                                    #times = 2,
                                    random = 1,
                                    #min_initial_points = ncol(modspec@grid[[1]]) + 1,
                                    packages = "rBayesianOptimization"))
  bayes_time <-
    (Sys.time() - sys_strt) %>% as.difftime(units = 'mins')
  
  #### #### #### ####
  ## Organize Results
  #### #### #### ####
  points_thompson <- ((summary(as.MLModel(fit_thompson)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_grid <- ((summary(as.MLModel(fit_grid)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_pso <- ((summary(as.MLModel(fit_pso)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  points_bayes <- ((summary(as.MLModel(fit_bayes)))[[1]]$metrics %>% unlist) %>% na.omit %>% c
  #### #### #### ####
  
  #### #### #### ####
  df <- na.omit(data.frame(
    optimizer =c(rep('thompson',length(points_thompson)),
                 rep('grid',length(points_grid)),
                 rep('pso',length(points_pso)),
                 rep('bayes',length(points_bayes))),
    iteration = c(1:length(points_thompson),
                  1:length(points_grid),
                  1:length(points_pso),
                  1:length(points_bayes)),
    performance = c(
      points_thompson,
      points_grid,
      points_pso,
      points_bayes
    ),
    is_best = (c(
      points_thompson == min(points_thompson),
      points_grid == min(points_grid),
      points_pso == min(points_pso),
      points_bayes == min(points_bayes)
    ))
  ))
  
  #### #### #### #### 
  ## Summary Statistics
  #### #### #### #### 
  mean_perf <- df %>%
    group_by(optimizer) %>%
    summarize(
      "Mean Performance" = mean(performance),
      "Median Performance" = median(performance),
      "SD Performance" = sd(performance),
      "Best Performance" = min_max(performance)
    )
  
  performance_summary <- data.frame(optimizer = c('thompson', 
                                                  'grid', 
                                                  'pso', 
                                                  'bayes')) %>%
    mutate(
      "Tuning Time per Grid Point" = c(thompson_time,
                                       grid_time,
                                       pso_time,
                                       bayes_time) / c(
                                         length(points_thompson),
                                         length(points_grid),
                                         length(points_pso),
                                         length(points_bayes)
                                       )
    ) %>%
    mutate("Total Tuning Time" = c(thompson_time,
                                   grid_time,
                                   pso_time,
                                   bayes_time)) %>%
    right_join(mean_perf)
  
  #### #### #### #### 
  ## Out-of-Grid Performance
  #### #### #### ####
  params <- colnames(modspec@grid[[1]])
  outcome <- modspec@params@metrics
  
  
  ## if out-of-grid predictions are to be plotted
  if (plot_preds) {
    ## Load fitted beta coefficients and design matrix from thompson
    load(paste0(seed,'_thompson.RData'))
    ## the actual components
    colnames(design_mat)[grep('degree=1', colnames(design_mat))] <- c(params)
    # save observed grid performance that the thompson optimization DID NOT evaluate
    obs <-
      rbind(cbind(
        cbind((
          summary(as.MLModel(fit_grid))
        )[[1]]$params[[1]]),
        ((
          summary(as.MLModel(fit_grid))
        )[[1]]$metrics %>% unlist)) %>%
          colrename(c(params,
                      outcome))) %>%
      rbind(cbind(cbind((
        summary(as.MLModel(fit_pso))
      )[[1]]$params[[1]]),
      ((
        summary(as.MLModel(fit_pso))
      )[[1]]$metrics %>% unlist)) %>%
        colrename(c(params,
                    outcome))) %>%
      rbind(cbind(cbind((
        summary(as.MLModel(fit_bayes))
      )[[1]]$params[[1]]),
      ((
        summary(as.MLModel(fit_bayes))
      )[[1]]$metrics %>% unlist)) %>%
        colrename(c(params,
                    outcome)))
    
    ## bind out-of-grid predictions and observed cross-validated performance
    out_of_grid_predictions <-
      as(design_mat[-grid_points, ], 'matrix') %*% betaknot_new
    out_of_grid_params <-  (modspec@grid[[1]])[-grid_points, ]
    out_of_grid_params$prediction <- -out_of_grid_predictions
    plot_dat <- merge(obs, out_of_grid_params, by = params)
    
    #### #### #### ####
    ## Return Results
    #### #### #### ####
    return(
      list(
        points_thompson = points_thompson,
        points_grid = points_grid,
        points_pso = points_pso,
        points_bayes = points_bayes,
        performance_summary = performance_summary,
        params = params,
        outcome = outcome,
        plot_dat = plot_dat,
        seed = seed
      )
    )
  } else {
    return(
      list(
        points_thompson = points_thompson,
        points_grid = points_grid,
        points_pso = points_pso,
        points_bayes = points_bayes,
        performance_summary = performance_summary,
        params = params,
        outcome = outcome,
        seed = seed
      )
    )
  }
}
################################################################################
## last filtering
combos <- unique(combos)
print(combos)

## run the empirical simulations
cl <- makeCluster(12)
registerDoParallel(cl)
clusterExport(cl,unique(ls(),as.character(lsf.str())))
for(string in combos){
  
  ## extract simulation parameters from string code
  print(string)
  split_string <- unlist(strsplit(string,
                                  "/"))
  split_first_split_string <- unlist(strsplit(split_string[1],
                                              "_"))
  
  ## run 10 repeats per circumstance
  print(paste0(paste0(split_string,collapse = ''),'.RData'))
  print("starting")
  run <- foreach(i = 1:24,.packages = c('doParallel',
                                        'recipes',
                                        'dplyr',
                                        'foreach',
                                        'MachineShop',
                                        'glmnet',
                                        'randomForestSRC',
                                        'kknn',
                                        'xgboost',
                                        'rBayesianOptimization',
                                        'nnet',
                                        'pso',
                                        'survival')) %dopar% {
                                          #write.csv('starting foreach',file = paste0(i,'_message.csv'))
                                          cl2 <- makeCluster(5)
                                          registerDoParallel(cl2)
                                          
                                          ## the seed is always the iteration number
                                          print(i)
                                          seed <- i
                                          set.seed(seed)
                                          
                                          ## extract the metric of interest
                                          met <- unlist(sapply(split_string[2],
                                                               function(x){
                                                                 if(x == 'microbiome') return('brier')
                                                                 if(x == 'microbiome_ranked') return('brier')
                                                                 if(x == 'mnist_train') return('accuracy')
                                                                 if(x == 'ames') return('rmse')
                                                                 if(x == 'HNSCC') return('cindex')
                                                                 if(x == 'nba') return('mae')
                                                               })[1])[1]
                                          names(met) <- NULL
                                          print(met)
                                          
                                          ## extract tuning grid
                                          tg <- tuning_grids[[split_first_split_string[1]]]
                                          
                                          ## correct splitrules per outcome type (for random forests)
                                          if(split_first_split_string[1] == 'RFSRCModel'){
                                            if(met == 'cindex'){
                                              tg <- tg[tg$splitrule %in% c(
                                                'logrank',
                                                'bs.gradient',
                                                'logrankscore'
                                              ),]
                                            } else if((met == 'brier') | (met == 'accuracy')){
                                              tg <- tg[tg$splitrule %in% c(
                                                'gini',
                                                'auc',
                                                'entropy'
                                              ),]
                                            } else if(met == 'rmse'){
                                              tg <- tg[tg$splitrule %in% c(
                                                'mse',
                                                'quantile.regr',
                                                'la.quantile.regr'
                                              ),]
                                            }
                                          }
                                          
                                          ## create a model specification object we are trying to tune
                                          modspec <- create_modspec(
                                            recipe = split_string[2],
                                            model = split_first_split_string[1],
                                            preprocess = paste0("step_",split_first_split_string[2]),
                                            metric = met,
                                            tuning_grid =
                                              tg
                                          )      
                                          
                                          ## whether the metric is to be maximized or minimized
                                          min_max_func <- function(x)min(x)
                                          if(met == 'cindex' | met == 'r2' | met == 'accuracy'){
                                            min_max_func <- function(x)max(x)
                                          }
                                          write.csv(paste0('run tune iteration ',string),file = 
                                                      paste0(i,'.csv'))
                                          
                                          ## tune the model specification using each optimizer
                                          ret <- run_tune_iteration(modspec,
                                                                    min_max = min_max_func)
                                          stopCluster(cl2)
                                          return(ret)
                                          
                                        }
  write.csv('save file',
            file = paste0(paste0(paste0(split_string,collapse = ''),
                                 '.csv')))
  
  ## save run 
  save(run,
       file = 
         paste0(paste0(split_string,collapse = ''),
                '.RData'))
  
}
stopCluster(cl)




