setwd("Z:/Dissertation/ResultsForDefense/")
library(MachineShop)
library(data.table)
data_files <- c(
  c(
    'GLMNetModel_noneames_best.RData',
    'GLMNetModel_nonehnscc_best.RData',
    'GLMNetModel_nonemicrobiome_ranked_best.RData',
    'RFSRCModel_noneames_best.RData',
    'RFSRCModel_nonehnscc_best.RData',
    'RFSRCModel_nonemicrobiome_ranked_best.RData',
    'XGBTreeModel_noneames_best.RData',
    'XGBTreeModel_nonehnscc_best.RData',
    'XGBTreeModel_nonemicrobiome_ranked_best.RData',
    'XGBwKMModel_nonemimic_best.RData',
    'NNetModel2_pcanba_best.RData'
  )
)
full_dat <- list()
for(data_file in data_files){
  load(data_file)
  s <- final_dat$summary[[1]]
  index <- which(s$selected)
  perf <- unlist(s$metrics[[1]])[index]
  params <- unlist(s[index,]$params)
  names(params) <- names(s$params[[1]])
  time <- as.numeric(difftime(final_dat$end,
                              final_dat$start,
                              units = 'secs'))
  dat <- data.frame(
    "Dataset/Model" = data_file,
    "Time" = time,
    "Metric" = toupper(names(s$metrics)[1]),
    "NTotal" = nrow(s),
    "Nbest" = index,
    "Performance" = perf
  )
  dat <- data.frame(t(unlist(c(dat,params))))
  write.csv(dat,
  file = paste0(data_file,'_.csv'),
  row.names = F)
  full_dat[[data_file]] <- dat
}
tab <- rbindlist(full_dat,fill = T)
write.csv(tab, file = "best_performances.csv",row.names = F)