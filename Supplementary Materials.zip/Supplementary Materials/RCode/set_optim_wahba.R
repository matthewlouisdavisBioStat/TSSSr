library(MachineShop)
library(foreach)
library(gss)
################################a################################################

## for centering and scaling and extracting components
center_and_scale <- function(x){
  xx <- na.omit(x)
  xx <- xx[is.finite(xx)]
  xx <- xx[!is.nan(xx)]
  if(length(xx) > 1){
    meann <- mean(xx[is.finite(xx)],na.rm = T)
    sdd <- sd(xx[is.finite(xx)],na.rm = T)
    if(sdd > 0){
      return(list((x-meann)/sdd,
                  meann,
                  sdd
      ))
    } else {
      return(list((x-meann),
                  meann,
                  1))
    }
  } else {
    return(list(x,
                0,
                1))
  }
}


## variance stabilizing/symmetry-inducing transformations
transf <- function(x,type,pwr_lmbda = NULL,...){
  #pwr_lmbda <- 0
  if(type == 'distance_type'){
    ## use box-cox
    if(pwr_lmbda != 0){
      (x^pwr_lmbda+1)/pwr_lmbda
      # x^pwr_lmbda
    } else {
      log(x)
    }
  } else if(type == 'proprotion_type'){
    ## use arcsin
    asin(sqrt(x))
  } else if(type == 'interval_type'){
    ## use hyperbolic-tangent transformation
    atanh(x)
  } else {
    return(...)
  }
}

## variance stablizing/symmetry-inducing back-transformations
un_transf <- function(x,type,pwr_lmbda = NULL,...){
  #pwr_lmbda <- 0
  if(type == 'distance_type'){
    if(pwr_lmbda != 0){
      (x * pwr_lmbda - 1)^(1 / pwr_lmbda)
      # x ^ (1 / pwr_lmbda)
    } else {
      exp(x)
    }
  } else if(type == 'proprotion_type'){
    (sin(x))^2
  } else if(type == 'interval_type'){
    tanh(x)
  } else {
    return(...)
  }
}

## Each metric gets assigned a grouping with associated transformation
distance_type_metrics <- c(
  "brier",
  "cross_entropy",
  "mae",
  "mse",
  "msle",
  "rmse",
  "rmsle"
)
proportion_type_metrics <- c(
  "accuracy",
  "cindex",
  "fnr",
  "fpr",
  "npv",
  "ppv",
  "ppr",
  "precision",
  "recall",
  "roc_auc",
  "sensitivity",
  "specificity",
  "tnr",
  "tpr",
  "gini"
)
interval_type_metrics <- c(
  "kappa2",
  "r2"
)

## assign a knot group (for quantiles q) to a vector x
get_group <- function(x,q,rev = F){
  if(length(q) > 1){
    rowsums <- rowSums(sapply(2:length(q),function(qq){
      qq*(x <= q[qq] &
            x > q[qq-1])
    }))
  } else {
    rowsums <- 0
  }
  rowsums + 
    ifelse(x <= q[1],
           1,
           0) +
    ifelse(x > q[length(q)],
           length(q)+1,
           0)
}

## generate inverse-gamma variables, with error handling
my_rinvgamma <- function(n, a, b, s){
  try <- rgamma(n, 
                a, 
                rate = b)
  t <- try({
    if(is.na(try)){
      return(s)
    } else {
      if(is.nan(try)){
        return(s)
      } else {
        if(!is.finite(try) | try < 1e-16){
          return(s)
        } else {
          return(1/try)
        }
      }
    }},silent = T)
  if(class(t) == 'try-error'){
    return(s)
  }
}


## fix na
fixna <- function(x){
  if(any(na.omit(c(is.na(x),
                   is.nan(x),
                   !is.finite(x))))){
    rep(0,length(x))
  } else {
    x
  }
}

optimStats <- function(...){
  stats::optim(...)
}
is.nanf <- function(x){
  sapply(x,function(xx)!is.finite(xx) | is.nan(xx) | is.na(xx))
}

## take the l2norm of a function
l2norm2 <- function(x,other_vec = 0)sqrt(mean(x-other_vec)^2)

## mogul optimization
set_optim_wahba <- function(   object, 
                               times = 10, # how many total grid points will be evaluated (including initial points evaluated)?
                               initial_points = 10, # how many grid points to default randomly sample first?
                               random = TRUE, # when algorithm fails, should all grid points or a single randomly sampled one (default) be evaluated?
                               use_transf = TRUE, # should a default variance-stabilizing transformation be used?
                               log_outcome = NULL, # should the metric being modeled be log-transformed as an outcome?
                               logit_outcome = NULL, # should the metric being modeled be logit-transformed as an outcome?
                               save_model_fit = FALSE, # should the design matrix and beta coefficients be saved to an RData file? 
                               include_numeric_interactions = T, # should numeric-numeric interactions be included?
                               include_high_order_interactions = F, # should degree 3-and-higher numeric polynomial terms and categorical interactions be included?
                               include_quadratic_interactions = F, # should degree 2 numeric polynomial terms and categorical interactions be included?
                               qualify_numeric_numeric_interactions = F, # should three-way interactions between categorical and first-order numeric pairings be included?
                               save_model_fit_lable = 'wahba_model_fit.RData', # label for the data file saving the beta coefficients and design matrix,
                               generic_tolerance = sqrt(.Machine$double.eps), # tolerance for convergence on a variety of tasks
						                   degree = 3, # max polynomial degree,
						                   first_gp = NULL, # used for the pathological simulation, may be ignored otherwise: controls which grid point to evaluate first
                               ... ) { # additional MachineShop arguments to be passed to the fun = (...) argument of set_optim_method
  num_knots <- 0
  min_initial_points <- initial_points
  max_initial_points <- initial_points
  override_initial_points <- F
  
  ## check for presence of input/model grids, and combine 
  ## we need to save the information about the input grid/model grid objects with respect to 
  ## 1) column names
  ## 2) whether or not they are null objects
  input_grid <- NULL
  model_grid <- NULL
  for(i in 1:length(object@grid)){
    grid <- object@grid[[i]]
    grid_name <- names(object@grid)[i]
    if(grid_name == object@model@id){
      model_grid <- grid
    }
    if(grid_name == object@input@id){
      input_grid <- grid
    }
  }
  if(is.null(input_grid) & is.null(model_grid)){
    stop("No tuning grids found: Please supply one")
  } else if(is.null(input_grid)){
    
    grid <- model_grid
    
    ## edit model grid so it isn't a null object, retains it's column names, but is of small size
    model_grid <- model_grid[1:2,]
  } else if(is.null(model_grid)){
    
    grid <- input_grid
    
    ## edit input grid so it isn't a null object, retains it's column names, but is of small size
    input_grid <- input_grid[1:2,]
  } else{
    
    grid <- expand_params(
      c(lapply(input_grid,unique),
        lapply(model_grid,unique))
    )
    
    ## edit both model and input grids so they aren't null objects, retain column names, but are of small size
    model_grid <- model_grid[1:2,]
    input_grid <- input_grid[1:2,]
  }
  grid_inds_to_keep <- 1:nrow(grid)
  
  ## fix list error
  grid_temp <- grid
  excl <- which(sapply(1:ncol(grid),function(i)(!(class(grid[[i]])[1] %in% c("numeric","integer","character","factor")))))
  t <- try({
    if(length(excl) > 0){
      grid_temp <- cbind(grid[[excl]],grid[,-excl])
      grid <- grid_temp
    } else{
      NULL
    }
  },silent = T)
  
  ## this happens when we tune over multiple/solely over categoricals
  if(class(t) == 'try-error'){
    t <- try({
      for(i in 1:ncol(grid)){
        if(!(class(grid[[i]])[1] %in% c("numeric","integer","character","factor"))){
          grid[[i]] <- unlist(grid[[i]])
        }
      }
    },silent = T)
  } else {
    gridname <- NULL
  }
  
  ## try making integers
  for(i in 1:ncol(grid)){
    if(class(unlist(grid[,i])[1]) == "numeric"){
      ## if the rounded values modulo observed values = 0, then we treat as integer
      if(!(any(round(grid[[i]]) - grid[[i]] != 0))){
        grid[[i]] <- as.integer(grid[[i]])
      }
    }
  }
  
  ## save for later
  og_grid <- grid
  og_normcats <- as.character(1:(num_knots+1))
  unq_g_1 <- apply(og_grid,2,function(x)length(unique(x)) > 1)
  integers <- which(sapply(og_grid[1, ], class) == "integer" & unq_g_1)
  numerics <- which(sapply(og_grid[1, ], class) == "numeric" & unq_g_1)
  cats <- which((sapply(og_grid[1, ], class) %in% c("factor", "character")) & 
                  unq_g_1)
  names(cats) <- names(og_grid[1, ])[cats]
  
  ## partition for knots, if numerics and/or integers available
  if(length(c(numerics,integers) > 0)){
    #### print('partinioning predictor space for knots')
    gridnumtemp <- as(grid[,c(numerics,integers)],'matrix')
    sdtemp <- apply(gridnumtemp,2,sd)
    degree1mat <- t(t(gridnumtemp) / sdtemp)
    prednorms <- apply(cbind(degree1mat),
                       1,
                       l2norm2)
    norms <- apply(degree1mat,1,l2norm2)#,colM)
    quants <- quantile(norms,seq(0,
                                 1,
                                 length.out = max(num_knots,1) + # ensures knots of 0 get treated as '1s'
                                   2)[-c(1,max(num_knots,1) + # ensures knots of 0 get treated as '1s'
                                           2)]
    )
    
    ## knot indices 
    knots <- sapply(quants,function(q){
      which(abs(norms-q) == min(abs(norms-q)))[1]
    })
    Q <- cbind(rep(1,length(norms)))
    
  }
  
  make_design_matrix <- function(grid,drop_cols = T, 
                                 quantiles = quants) {
    ## create design matrix of numeric/integer components for polynomial regre
    ## [degree] columns will be included for each parameter "x" : x, x^2, x^3,....x^degree
    if (length(c(integers, numerics)) > 0) {
      design_mat_num <- foreach(var = (c(integers,
                                         numerics)), .combine = 'cbind') %do% {
                                           if (degree > 1) {
                                             sapply(1:round(degree), function(d) {
                                               as.numeric(unlist(grid[, var])) ^ d
                                             })
                                           } else{
                                             as.numeric(c(unlist(grid[, var])))
                                           }
                                         }
      colnames(design_mat_num) <-
        rep(paste0("degree=", 1:degree), length(c(integers, numerics)))
      colnames(design_mat_num) <-
        paste(rep(
          names(c(integers, numerics
          )),
          each = degree), 
          colnames(design_mat_num), 
          sep = "_")
      if (ncol(design_mat_num) == 0) {
        design_mat_num <- NULL
      }
    } else{
      design_mat_num <- NULL
    }
    
    ## create design matrix of categorical indicators:
    if (length(cats) > 0) {
      design_mat_cat <- foreach(cat = cats, .combine = 'cbind') %do% {
        # if the category has more than one unique value, include it in the design matrix, else exclude it
        if (length(unique(og_grid[[cat]])) > 1) {
          foreach(var = cat, .combine = 'cbind') %do% {
            f <-
              foreach(category = unique(unlist(og_grid[, var])), .combine = 'cbind') %do% {
                as.numeric(grid[, var] == category)
              }
            colnames(f) <-
              paste(colnames(grid)[var], unique(unlist(og_grid[, var])), sep = "=")
            f
          }
        } else{
          cbind(rep(0, nrow(grid)))
        }
      }
      if(drop_cols){
        design_mat_cat <-
          design_mat_cat[, apply(design_mat_cat, 2, function(x)
            any(x != 0))]
      } else {
        design_mat_cat <-
          design_mat_cat[, apply(design_mat_cat, 2, function(x)
            any(x != -Inf))]
      }
      
    } else {
      ## without any categorical variables, we include an intercept into the design matrix
      design_mat_cat <- cbind(rep(1, nrow(grid)))
      colnames(design_mat_cat) <- c("intercept")
    }
    
    
    
    ## add in interactions
    interactions <- NULL
    if (!is.null(design_mat_cat) & !is.null(design_mat_num)) {
      if (ncol(design_mat_cat) > 1) {
        first_ind <- ifelse(drop_cols,2,1)
        cat_num_interactions <-
          foreach(i = first_ind:ncol(design_mat_cat), # drop first category
                  .combine = 'cbind') %do% {
                    foreach(j = seq(1, ncol(design_mat_num), by = 1),
                            .combine = 'cbind') %do% {
                              design_mat_cat[, i] * 
                                design_mat_num[, j]
                            }
                  }
        sq <- seq(1, ncol(design_mat_num), by = degree)
        colnames(cat_num_interactions) <-
          foreach(i = first_ind:ncol(design_mat_cat),
                  .combine = 'c') %do% {
                    foreach(j = seq(1, ncol(design_mat_num), by = 1),
                            .combine = 'c') %do% {
                              paste0(colnames(design_mat_cat)[i],
                                     "xZx",
                                     colnames(design_mat_num)[j])
                              
                            }
                  }
        
        if(drop_cols & 
           degree >= 3 & 
           !include_high_order_interactions){
          cat_num_interactions <- 
            cat_num_interactions[,-which(sapply(colnames(cat_num_interactions),function(col){
              any(sapply(paste0("degree=",3:degree),function(nam)grepl(nam,col)))
            }))]
        }
        if(drop_cols & 
           degree >= 3 & 
           !include_quadratic_interactions){
          cat_num_interactions <- 
            cat_num_interactions[,-which(sapply(colnames(cat_num_interactions),function(col){
              any(sapply(paste0("degree=",2),function(nam)grepl(nam,col)))
            }))]
        }
        cat_interactions <-
          foreach(i = 1:ncol(design_mat_cat),
                  .combine = 'cbind') %do% {
                    foreach(j = c(1:ncol(design_mat_cat))[(c(1:ncol(design_mat_cat)) != i)],
                            .combine = 'cbind') %do% {
                              (design_mat_cat[, j]) * 
                                (design_mat_cat[, i])
                            }
                  }
        colnames(cat_interactions) <-
          foreach(i = 1:ncol(design_mat_cat),
                  .combine = 'c') %do% {
                    foreach(j = c(1:ncol(design_mat_cat))[(c(1:ncol(design_mat_cat)) != i)],
                            .combine = 'c') %do% {
                              paste0(colnames(design_mat_cat)[j],
                                     "xXx",
                                     colnames(design_mat_cat[i]))
                            }
                  }
        # remove redundant interactions between linearly-independent categories
        if(drop_cols){
          design_mat_cat <-
            design_mat_cat[, apply(design_mat_cat, 2, function(x)
              any(x != 0))]
        } else {
          design_mat_cat <-
            design_mat_cat[, apply(design_mat_cat, 2, function(x)
              any(x != -Inf))]
        }
        #### print('num interactions')
        ## numeric interactions
        num_interactions <-
          foreach(i = seq(1, ncol(design_mat_num), by = degree), .combine = 'cbind') %do% {
            foreach(j = c(seq(1, ncol(
              design_mat_num
            ), by = degree))[c(seq(1, ncol(design_mat_num), by = degree)) > i],
            .combine = 'cbind') %do% {
              design_mat_num[, j] * design_mat_num[, i]
            }
          }
        
        colnames(num_interactions) <- foreach(i = seq(1, ncol(design_mat_num), by = degree), .combine = 'c') %do% {
          foreach(j = c(seq(1, ncol(
            design_mat_num
          ), by = degree))[c(seq(1, ncol(design_mat_num), by = degree)) > i],
          .combine = 'c') %do% {
            paste0(colnames(design_mat_num)[j],
                   "xXx",
                   colnames(design_mat_num)[i])
          }
        }
        
        ## now, adjust the numeric interactions so they are conditional on category
        if(!is.null(ncol(num_interactions))){
          cat_num_num_interactions <-
            foreach(i = first_ind:ncol(design_mat_cat), # drop first category
                    .combine = 'cbind') %do% {
                      foreach(j = seq(1, ncol(num_interactions), by = 1),
                              .combine = 'cbind') %do% {
                                design_mat_cat[, i] * 
                                  num_interactions[, j]
                              }
                    }
          sq <- seq(1, ncol(num_interactions), by = degree)
          colnames(cat_num_num_interactions) <-
            foreach(i = first_ind:ncol(design_mat_cat),
                    .combine = 'c') %do% {
                      foreach(j = seq(1, ncol(num_interactions), by = 1),
                              .combine = 'c') %do% {
                                paste0(colnames(design_mat_cat)[i],
                                       "xxYYzz",
                                       colnames(num_interactions)[j])
                                
                              }
                    }
        }
        
        #### print('binding')
        if (ncol(cat_interactions) > 0 & qualify_numeric_numeric_interactions) {
          interactions <-
            cbind(cbind(cat_num_interactions, cat_interactions),
                  num_interactions,
                  cat_num_num_interactions)
        } else if (ncol(cat_interactions) > 0 & !qualify_numeric_numeric_interactions) {
          interactions <-
            cbind(cbind(cat_num_interactions, cat_interactions),
                  num_interactions)
        } else{
          interactions <- cbind(cat_num_interactions, num_interactions)
        }
      } else {
        ## when only numeric variables are being tuned
        interactions <-
          foreach(i = seq(1, ncol(design_mat_num), by = degree), .combine = 'cbind') %do% {
            foreach(j = c(seq(1, ncol(
              design_mat_num
            ), by = degree))[c(seq(1, ncol(design_mat_num), by = degree)) > i],
            .combine = 'cbind') %do% {
              design_mat_num[, j] * design_mat_num[, i]
            }
          }
        
        colnames(interactions) <- foreach(i = seq(1, ncol(design_mat_num), by = degree), .combine = 'c') %do% {
          foreach(j = c(seq(1, ncol(
            design_mat_num
          ), by = degree))[c(seq(1, ncol(design_mat_num), by = degree)) > i],
          .combine = 'c') %do% {
            paste0(colnames(design_mat_num)[j],
                   "xXx",
                   colnames(design_mat_num)[i])
          }
        }
      }
      
      ## if there are just categorical, try to make interactions
    } else {
      if (ncol(design_mat_cat) > 1) {
        interactions <-
          foreach(i = 1:ncol(design_mat_cat),
                  .combine = 'cbind') %do% {
                    foreach(j = c(1:ncol(design_mat_cat))[c(1:ncol(design_mat_cat)) != i], .combine = 'cbind') %do% {
                      design_mat_cat[, j] * design_mat_cat[, i]
                    }
                  }
        colnames(interactions) <-
          foreach(i = 1:ncol(design_mat_cat),
                  .combine = 'c') %do% {
                    foreach(j = c(1:ncol(design_mat_cat))[c(1:ncol(design_mat_cat)) != i],
                            .combine = 'c') %do% {
                              paste0(colnames(design_mat_cat)[j],
                                     "xXx",
                                     colnames(design_mat_cat)[i])
                            }
                  }
        ## remove redundant interactions between linearly-independent categories
        if(drop_cols){
          interactions <-
            interactions[, apply(interactions, 2, function(x)
              any(x != 0))]
        } else {
          interactions <-
            interactions[, apply(interactions, 2, function(x)
              any(x != -Inf))]
        }
        if (ncol(interactions) == 0) {
          interactions <- NULL
        }
      }
    }
    
    ## combine into one design matrix
    #### print('merging design matrices')
    if (is.null(design_mat_cat)) {
      if(drop_cols){
        design_mat_num <-
          design_mat_num[, which(apply(design_mat_num, 2, function(x)
            length(unique(x)) > 1))]
      } else {
        design_mat_num <-
          design_mat_num[, which(apply(design_mat_num, 2, function(x)
            length(unique(x)) > -Inf))]
      }
      design_mat <- cbind(design_mat_num)
    } else if (is.null(design_mat_num)) {
      design_mat <- cbind(design_mat_cat)
    } else {
      if(drop_cols){
        design_mat_num <-
          design_mat_num[, which(apply(design_mat_num, 2, function(x)
            length(unique(x)) > 1))]
      } else {
        design_mat_num <-
          design_mat_num[, which(apply(design_mat_num, 2, function(x)
            length(unique(x)) > -Inf))]
      }
      design_mat <- as(cbind(design_mat_num, design_mat_cat),
                       'matrix')
    }
    if (!is.null(interactions)) {
      colnames(interactions) <-
        ## interactions get penalized equal to the highest degree being fit + 1 + 1(3-way interaction)
        paste(colnames(interactions), paste0("",
                                             ifelse(grepl('xZx',colnames(interactions)), # keep degree of numeric for the catnum quadratic interactions right!!
                                                    "",
                                                    paste0("_degree=",#degree# + 
                                                           2 + # pairwise interactions
                                                             1*grepl('xxYYzz',colnames(interactions)) # 3-way interactions
                                                    ))), 
              sep = "")
      design_mat <- cbind(design_mat, interactions)
    }
    
    ## exclude columns with only 1 unique value, unless of course, the column is the intercept column
    if(drop_cols){
      design_mat <- design_mat[,
                               which(sapply(1:ncol(design_mat),
                                            function(x)
                                              (length(unique(design_mat[, x])) > 1)|
                                              (colnames(design_mat)[x])=="intercept"))]
    } else {
      design_mat <- design_mat[,
                               which(sapply(1:ncol(design_mat),
                                            function(x)
                                              (length(unique(design_mat[, x])) > -Inf)|
                                              (colnames(design_mat)[x])=="intercept"))]
    }
    #### print('finished making design matrix')
    return(design_mat)
  }
  
  design_mat <- make_design_matrix(grid,drop_cols = T)
  ## scale so all variables have equal sd
  sds <- apply(design_mat,2,function(x)if(any(!(unique(x) %in% c(0,1)))) sd(x) else 1)
  for(j in 1:length(sds)){
    design_mat[,j] <- 
      design_mat[,j]/sds[j]
  }
  
  knot_expand <- function(mat,nk,quantz,
                          max_degree = 3,
                          move_up_1 = F,
                          rawmat = NULL){
    if(nk == 1){
      return(mat)
    } else {
      if(is.null(rawmat)){
        rawmat <- mat
      }
      expanded_X <- mat[,rep(1:ncol(mat),nk)]
      colz <- colnames(mat)
      temp_degree1mat <- cbind(rawmat[,grepl('_degree=1',colz) &
                                        substr(colz,1,nchar(colz) - 9) %in% 
                                        names(c(numerics,integers))])
      temp_norms <- apply(cbind(temp_degree1mat),1,l2norm2)
      knotgroup <- get_group(temp_norms,quantz)
      if(move_up_1){
        knotgroup <- knotgroup + 1
      } 
      knot_indices <- foreach(nkk = 1:nk,.combine = 'cbind') %do% {
        cbind(1*(knotgroup == nkk))[,rep(1,ncol(mat))]
      }
      newmat <- expanded_X*knot_indices
      colnames(newmat) <- rep(colz,nk)
      newmat
    }
  }
  ## save results to outcome vector
  y <- c()
  if(!include_numeric_interactions){
    design_mat <- design_mat[,!grepl('xXx',colnames(design_mat))]
  }
  print(cbind(colnames(design_mat)))
  
  ## number of columns of spline-free cubic regression
  p0 <- ncol(design_mat)
  
  ## center the knot quantiles 
  colz <- colnames(cbind(design_mat))
  ov <- colMeans(cbind(cbind(design_mat)[,grepl('_degree=1',colz) &
                                          substr(colz,1,nchar(colz) - 9) %in% 
                                          names(c(numerics,integers))]))
  deg1vars <- names(ov)
  if(length(cats) > 1){
    deg1vars <- c(deg1vars,colnames(design_mat)[!(grepl('degree=',colnames(design_mat)))])
  }
  if(is.null(deg1vars)){
    deg1vars <- colz[1]
  }
  ##############################################################################
  set_optim_method(
    object,
    fun = function(optim, grid, ...) {
      grid <- grid[grid_inds_to_keep,]
      if(override_initial_points){
        initial_iterations <- max(min_initial_points,ncol(design_mat) + 3)
      } else {
        initial_iterations <- min_initial_points
      }
      old_times <- times
      times <- max(0, times - initial_iterations)
      if((initial_iterations > old_times) & override_initial_points){
        initial_iterations <- old_times
      }
	     ## no more than this amount will be initially randomly sampled
	    if(initial_iterations > max_initial_points){
		    initial_iterations <- max_initial_points
	    }
      print(paste0(c('initial iterations: ', initial_iterations),collapse = ""))
      ## if there are 3 or less rows, just evaluate them all and be done with it
      if(initial_iterations >= nrow(grid)){
        for(i in 1:nrow(grid)){
          optim(grid[i,])
        }
      } else{
        
        grid_points <- sample(1:nrow(grid),initial_iterations)
        grid_points_dummy <- c()
        ## adjust because we need to get the max/min of every variable
        ## for running ssanova (no extrapolation allowed)
        for(v in 1:length(deg1vars)){
          col <- deg1vars[v]
          grid_points_dummy <- c(
            grid_points_dummy,
            (which(cbind(design_mat)[,col] == max(cbind(design_mat)[,col])))[1],
            (which(cbind(design_mat)[,col] == min(cbind(design_mat)[,col])))[1]
          )
        }
        grid_points_dummy <- unique(grid_points_dummy)
        if(length(grid_points_dummy) < length(grid_points)){
          grid_points[1:length(grid_points_dummy)] <- grid_points_dummy
        } else {
          grid_points <- grid_points_dummy
          initial_iterations <- length(grid_points)
        }
        
        count <- 1
        if(!is.null(first_gp)){
          print(grid_points)
          grid_points <- c(grid_points,first_gp)
          print(grid_points)
        }
        for (i in grid_points){
          opt <- optim(grid[i, ])
          if(count == 1 & any(!is.na(opt))){
            count <- 2
            metrics <- tolower(unique(names(na.omit(opt)))[1])
            if(metrics == 'c-index' | metrics == 'cindex'){
              metric <- metricinfo('cindex')[[1]]
            } else {
              metric <- metricinfo(metrics[[1]])[[1]]
            }
          }
          y[paste0(i)] <- opt
        }
        
        if((metrics == 'c-index' | metrics == 'cindex')){
          metrics <- 'cindex'
        } 
        raw_y <- y
        best_y <- max(y,na.rm = T)
        transf_sign <- ifelse(metric$maximize,1,-1)
        if(!use_transf){
          if(is.null(log_outcome)){
            log_outcome <- F
          }
          if(log_outcome){
            y <- transf_sign*log(transf_sign*y + sqrt(1e-16))
          }
          if(is.null(logit_outcome)){
            logit_outcome <- F
          }
          if(logit_outcome){
            y <- transf_sign*(log(transf_sign*y+sqrt(1e-16)) - log(1-transf_sign*y+sqrt(1e-16)))
          }
        } else {
          if(metrics %in% distance_type_metrics){
            names_y <- names(y)
            y <- transf_sign*y
            which <- which(!is.nan(y) &
                             is.finite(y) &
                             !is.na(y))
            shap_l <- min(length(y[which]),5000)
            if(length(unique(y)) > 1){
              pwr_lmbda_opt <- try({optimize(
                f = function(l){
                  z <- (transf(y[which],'distance_type',pwr_lmbda = l))
                  -log(shapiro.test(sample(z,shap_l)
                  )$p.value
                  )
                },
                lower = -1,
                upper = 1
              )[[1]]},silent = TRUE)
              if(any(class(pwr_lmbda_opt) == 'try-error')){
                print(pwr_lmbda_opt)
                pwr_lmbda_opt <- 1
              }
              y <- transf_sign*c(transf(y, 
                                        'distance_type',
                                        pwr_lmbda = pwr_lmbda_opt))
              names(y) <- names_y
            } else {
              pwr_lmbda_opt <- 1
            }
          } else if(metrics %in% proportion_type_metrics){
            y <- transf_sign*y
            y <- transf_sign*transf(y,'proprotion_type')
          }  else if(metrics %in% interval_type_metrics){
            y <- transf_sign*y
            y <- transf_sign*transf(y,'interval_type')
          } else {
            y <- transf_sign*y
          }
        }
        
        
        ## start cleaning out potential outliers when modelling 
        y[!is.finite(y)] <- NA
        lm <- lm(y[!is.na(y)] ~ 1)
        outliers <- which(abs(resid(lm)-mean(resid(lm)))/sd(resid(lm)) > 10)
        y[!is.na(y)][outliers] <- NA
        cs <- center_and_scale(y)
        y <- cs[[1]]
        mu <- cs[[2]]
        sig <- cs[[3]]
        
        inds_to_rem <- which(is.na(y))
        if(length(inds_to_rem) > 0){
          nas <- as.numeric(names(y[inds_to_rem]))
        } else{
          nas <- NULL
        }
        nas <- as.numeric(names(y[inds_to_rem]))
        clnms <- deg1vars
        terms <- unique(c(sapply(1:length(clnms),function(i){
          sapply(1:length(clnms),function(j){
            if(i < j){
              paste0(clnms[i],"*",clnms[j])
            } else{
              paste0(clnms[i])
            }
          })
        })))
        dat <- data.frame("y" = y,
                   design_mat[as.numeric(names(y)),clnms])
        fit <- ssanova(y ~ .,
                       data=dat)
        tempdat <- cbind(design_mat[-as.numeric(names(y)),clnms])
        colnames(tempdat) <- colnames(dat)[-1]
        preds <- predict(fit,newdata = tempdat)
        preds[is.na(preds)] <- min(preds,na.rm = T)
        preds[!is.finite(preds)] <- min(preds,na.rm = T)
        
        # initialize
        steps <- 0
         if (length(preds) > 1){
          while((length(preds) > 1) & (length(y) < (old_times))){
            
            candidates <- c(c(1:nrow(grid))[-as.numeric(names(y))])
            new_grid_point <- candidates[which(preds == max(preds))][1]
            y <- y * sig + mu
            gp <- new_grid_point
            opt <- optim(grid[gp,])
              if(!use_transf){
                if(log_outcome){
                  y[paste0(gp)] <- transf_sign*log(transf_sign*opt+sqrt(1e-16))
                } else if(logit_outcome){
                  y[paste0(gp)] <- transf_sign*log(transf_sign*opt+sqrt(1e-16)) - 
                    transf_sign*log(1-transf_sign*opt+sqrt(1e-16))
                } else {
                  y[paste0(gp)] <- transf_sign*opt
                } 
              } else {
                if(metrics %in% distance_type_metrics){
                  raw_y <- un_transf(transf_sign*y,
                                     'distance_type',
                                     pwr_lmbda = pwr_lmbda_opt)
                  names(raw_y) <- names(y)
                  opt <- transf_sign*opt
                  which <- which(
                    !is.nan(c(raw_y,opt)) &
                    is.finite(c(raw_y,opt)) &
                    !is.na(c(raw_y,opt)))
                  shap_l <- min(length(c(raw_y,opt)[which]),5000)
                  if(length(unique(y)) > 1){
                    pwr_lmbda_opt <- try({optimize(
                      f = function(l){
                        z <- (transf(c(raw_y,opt)[which],
                                     'distance_type',
                                     pwr_lmbda = l))
                        -log(shapiro.test(sample(z,shap_l)
                           )$p.value
                           )
                      },
                      lower = -1,
                      upper = 1
                    )[[1]]},silent = TRUE)
                    if(any(class(pwr_lmbda_opt) == 'try-error')){
                      print(pwr_lmbda_opt)
                      pwr_lmbda_opt <- 1
                    }
                    y <- transf_sign*transf(c(raw_y,opt),
                                            'distance_type',
                                            pwr_lmbda = pwr_lmbda_opt)
                    names(y) <- c(names(raw_y),
                                  paste0(gp))
                  } #
                } else if(metrics %in% proportion_type_metrics){
                  opt <- transf_sign*opt
                  y[paste0(gp)] <- transf_sign*
                    transf(opt,'proprotion_type')
                } else if(metrics %in% interval_type_metrics){
                  opt <- transf_sign*opt
                  y[paste0(gp)] <- transf_sign*
                    transf(opt,'interval_type')
                } else {
                  y[paste0(gp)] <- transf_sign*opt
                }
              }
            
            
            ## remove outliers
            y[!is.finite(y)] <- NA
            lm <- lm(y[!is.na(y)] ~ 1)
            outliers <- which(abs(resid(lm)-mean(resid(lm)))/sd(resid(lm)) > 10)
            y[!is.na(y)][outliers] <- NA
            cs <- center_and_scale(y)
            y <- cs[[1]]
            mu <- cs[[2]]
            sig <- cs[[3]]
            
            inds_to_rem <- which(is.na(y))
            if(length(inds_to_rem) > 0){
              nas <- as.numeric(names(y[inds_to_rem]))
            } else{
              nas <- NULL
            }
            
            Y <- y[!(as.numeric(names(y)) %in% nas)]
            ## re-fit
            dat <- data.frame("y" = Y,
                              design_mat[as.numeric(names(Y)),clnms])
            fit <- ssanova(y ~ .,
                           data=dat)
            tempdat <- cbind(design_mat[-as.numeric(names(y)),clnms])
            colnames(tempdat) <- colnames(dat)[-1]
            preds <- predict(fit,newdata = tempdat)
            preds[is.na(preds)] <- min(preds,na.rm = T)
            preds[!is.finite(preds)] <- min(preds,na.rm = T)
            steps <- steps + 1
          }
        } else {
          NULL
        }
      }
      return(NULL)
    },
    label = "Greedy Smoothing Spline ANOVA for Optimization",
    random = random
  )
}
