
  ## Getting the Best Results Using Stopping Rule: NBA

set.seed(52245)
source('set_optim_thompson.R')
source('create_modspec.R')

use_wahba <- F # are we comparing to traditional optimizers or Greedy Wahba?
if(use_wahba){
  source('set_optim_wahba.R')
}

## data sets
datasets <- c(
  'nba'
)
model_preps <- c(
  "NNetModel2_pca"
)
NNetModel2 <- NNetModel(maxit = 1000,MaxNWts = 10000000)
################################################################################
## functions for performing latin-grid sampling
sample_between_intervals <- function(x){
  intervals <- sort(unique(x))
  if(length(intervals) >= length(x)/2){
    x
  } else {
    sapply(x,function(y){
      ## if on the max, generate a uniform between a randomly-selected interval
      if (y == max(intervals)){
        s <- sample(1:(length(intervals)-1),1)
        runif(1,intervals[s],intervals[s+1])
        ## otherwise, generate uniform between obs and next interval
      } else {
        runif(1,y,min(intervals[intervals > y]))
      }
    })
  }
}
latin_grid <- function(grid){
  unq_g_1 <- apply(grid,2,function(x)length(unique(x)) > 1)
  numerics <- which(sapply(grid[1, ], class) == "numeric" & unq_g_1)
  for(num in c(numerics)){
    if(length(unique(unlist(grid[[num]]))) <= length(unlist(grid[[num]]))/4){
      grid[[num]] <- sample_between_intervals(as.numeric(unlist(grid[[num]])))
    }
  }
  return(grid)
}
################################################################################
## tuning grids here
tuning_grid_nnet <- expand_params(
  decay = seq(0,5,length.out = 250)^4,
  size = 2:25
)
################################################################################
## list of all tuning grids, latin grid'd if necessary
tuning_grids <- list(
  NNetModel2 = tuning_grid_nnet
)
## setup all of the parameters for simulations into a vector of strings
combos <- unique(
  c(apply(
    expand.grid(model_preps,
              datasets),
    1,
    paste0, collapse = "/"
)))
################################################################################
print(combos)

## run the empirical simulations
#cl <- makeCluster(1)
#registerDoParallel(cl)
#clusterExport(cl,unique(ls(),as.character(lsf.str())))
foreach(string = combos,.packages = c('doParallel',
                            'recipes',
                            'dplyr',
                            'foreach',
                            'MachineShop',
                            'glmnet',
                            'randomForestSRC',
                            'kknn',
                            'xgboost',
                            'rBayesianOptimization',
                            'nnet',
                            'pso',
                            'survival',
                            'gss')) %do% {
  
  ## extract simulation parameters from string code
  print(string)
  split_string <- unlist(strsplit(string,
                           "/"))
  split_first_split_string <- unlist(strsplit(split_string[1],
                                              "_"))
  print(paste0(paste0(split_string,collapse = ''),'.RData'))
  print("starting")
  i <- 1
                                            
      cl2 <- makeCluster(10)
      registerDoParallel(cl2)
      
      ## the seed is always the iteration number
      print(i)
      seed <- i
      set.seed(seed)

	    ## extract the metric of interest
      met <- unlist(sapply(split_string[2],
                           function(x){
                             if(x == 'microbiome_ranked') return('brier')
                             if(x == 'mnist_train') return('accuracy')
                             if(x == 'ames') return('rmse')
                             if(x == 'hnscc' | x == 'mimic') return('cindex')
                             if(x == 'nba') return('mae')
                           })[1])[1]
      names(met) <- NULL
      print(met)

	    ## extract tuning grid
      tg <- tuning_grids[[split_first_split_string[1]]]

      ## correct splitrules per outcome type (for random forests)
      if(split_first_split_string[1] == 'RFSRCModel'){
        if(met == 'cindex'){
          tg <- tg[tg$splitrule %in% c(
            'logrank',
            'bs.gradient',
            'logrankscore'
          ),]
        } else if((met == 'brier') | (met == 'accuracy')){
          tg <- tg[tg$splitrule %in% c(
            'gini',
            'auc',
            'entropy'
          ),]
        } else if(met == 'rmse'){
          tg <- tg[tg$splitrule %in% c(
            'mse',
            'quantile.regr',
            'la.quantile.regr'
          ),]
        }
      }

      ## create a model specification object we are trying to tune
      modspec <- create_modspec(
        recipe = split_string[2],
        model = split_first_split_string[1],
        preprocess = paste0("step_",split_first_split_string[2]),
        metric = met,
        tuning_grid =
          tg
      )      

	    ## whether the metric is to be maximized or minimized
      min_max_func <- function(x)min(x)
      if(met == 'cindex' | met == 'accuracy'){
        min_max_func <- function(x)max(x)
      }
      write.csv(paste0('run tune iteration ',string),file = 
                  paste0(i,'_dissertation_best.csv'))
	
      ## tune the model specification using each optimizer
      strt_time <- Sys.time()
      final_fit <- modspec %>%
        set_optim_thompson(times = 250,
                           initial_points = 10,
                           stopping_rule_total = 25,
                           plot_predicted_performance = F) %>% 
        fit
      end_time <- Sys.time()
      stopCluster(cl2)
      final_dat <- list('summary' = summary(as.MLModel(final_fit)),
                        'start' = strt_time,
                        'end' = end_time)
      save(final_dat,file = paste0(paste0(split_string,
                                                         collapse = ''),
                                                  '_best.RData'))
}
stopCluster(cl)




