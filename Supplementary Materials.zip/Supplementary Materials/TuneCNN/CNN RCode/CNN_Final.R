library(MachineShop)
library(recipes)
library(foreach)
library(keras)
################################################################################
CNN <- function(          activation_conv1 = "relu",
                          activation_conv2 = "relu",
                          activation_dense = "relu",
                          activation_dense2 ="relu",
                          units_conv1 = 10L,
                          units_conv2 = 5L,
                          units_dense1 = 2L,
                          units_dense2 = 2L,
                          l1_conv = 0,
                          l1_dense = 0,
                          l2_conv = 0,
                          l2_dense = 0,
                          kernel_size1 = 3,
                          pool_size1 = 2,
                          kernel_size2 = 3,
                          pool_size2 = 2,
                          num_comp = 0,
                          dr_conv = 0.025,
                          dr_dense = 0.025,
                          batch_size = 320L,
                          epochs = 5, 
                          idvar = "image",
                          timevar = "pixel_row",
                          period = 28,
                          loss = loss_categorical_crossentropy(),
                          exclude_inds = -1,
                          verbose = F,
                          outcomes = paste0('r',1:10),
                          save_tensors = F, # should the tensors be saved?
                          tensor_file = "tensors_train_cut.RData",
                          load_tensors = T,
                          metrics = "accuracy",
                          base_model = keras_model_sequential(),
                          ...){
  
  MLModel(
    name = "CNNModel",
    packages = c("keras",
                 "foreach",
                 "recipes",
                 "dplyr",
                 "reticulate",
                 "generics"),
    response_types = c("numeric","matrix"),
    weights = TRUE,
    params = list('activation_conv1'= activation_conv1,
                  'activation_conv2' = activation_conv2,
                  'activation_dense' = activation_dense,
                  'units_conv1' = units_conv1,
                  'units_conv2' = units_conv2,
                  'units_dense1' = units_dense1,
                  'units_dense2' = units_dense2,
                  'l1_conv' = l1_conv,
                  'l2_conv' = l2_conv,
                  'l1_dense' = l1_dense,
                  'l2_dense' = l2_dense,
                  'num_comp' = num_comp,
                  'batch_size' = batch_size,
                  'epochs' = epochs,
                  'kernel_size1' = kernel_size1,
                  'pool_size1' = pool_size1,
                  'kernel_size2' = kernel_size2,
                  'pool_size2' = pool_size2,
                  'dr_conv' = dr_conv,
                  'dr_dense' = dr_dense),
    fit = function(formula, 
                   data, 
                   activation_conv1,
                   activation_conv2,
                   activation_dense,
                   units_conv1,
                   units_conv2,
                   units_dense1,
                   units_dense2,
                   l1_conv,
                   l2_conv,
                   l1_dense,
                   l2_dense,
                   num_comp,
                   batch_size,
                   epochs,
                   kernel_size1,
                   pool_size1,
                   kernel_size2,
                   pool_size2,
                   dr_conv,
                   dr_dense,
                   ...) {
      
      message <- 'started'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      ## clean data
      data <- as.data.frame(data)
      data[,grepl('weights',colnames(data))] <- NULL
      data[,grepl('(names)',colnames(data))] <- NULL
      data[,grepl('strata.',colnames(data))] <- NULL
      
      ## extract the predictors for principal components
      predictors <- colnames(data)[-c(1:length(outcomes))]
      predictors <- predictors[sapply(predictors,function(x)class(data[[x]][1]) == 'numeric')]
      predictors <- predictors[!(predictors %in% c(idvar,
                                                   timevar))]
      predictors <- predictors[apply(data[,predictors],2,sd) > 0.00001]
      message <- 'about_to_normalize'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      ## construct recipes for applying normalization and/or PCA
      if(num_comp == 0){
        rcp <- recipe(. ~ .,
                      data = as.data.frame(apply(as(data[,predictors],'matrix'),
                                                 2,
                                                 as.numeric))) %>%
          step_YeoJohnson(all_of(predictors)) %>% 
          step_center(all_of(predictors)) %>%
          step_scale(all_of(predictors))
      } else {
        rcp <- recipe(. ~ .,
                      data = as.data.frame(apply(as(data[,predictors],'matrix'),
                                                 2,
                                                 as.numeric))) %>%
          step_YeoJohnson(all_of(predictors)) %>% 
          step_center(all_of(predictors)) %>%
          step_scale(all_of(predictors)) %>%
          step_pca(all_of(predictors),
                   num_comp = num_comp)
      }
      rcp_jc <- rcp %>%
        prep %>%
        juice
      
      
      ## replace original predictors with principal components
      data <- cbind(data[,!(colnames(data) %in% predictors)],
                    rcp_jc) %>% 
        as.data.frame
      
      message <- 'normalizations_and_binding_complete'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      
      ## start constructing tensors per observation
      made_samples <- F
      targets <- array(rep(0,length(outcomes)), 
                       dim = c(nrow(data),length(outcomes)))
      j <- 0
      train_inds <- rep(0,nrow(data))
      if(load_tensors){
        message <- 'about_to_load_tensor_file'
        write.csv(message,file = paste0(message,'.csv'),row.names = F)
        load(tensor_file)
        message <- 'successfully_loaded_tensor_file'
        write.csv(message,file = paste0(message,'.csv'),row.names = F)
        ## dummy code to keep consistency while extracting save cols
        j <- which(data[[timevar]] >= period)[1]
        id <- unlist(data[[idvar]])[j]
        game <- unlist(data[[timevar]])[j]
        subs <- data[ (unlist(data[[idvar]]) == id) &
                        (unlist(data[[timevar]]) %in% rev(1:game)[1:period]),]
        subs <- subs[order(subs[[timevar]]),]
        subs[[idvar]] <- NULL
        mat <- as(subs[,-1],
                  'matrix')
        save_cols <- colnames(mat)
        made_samples <- T
      } else {
        for(j in 1:nrow(data)){
          if(data[[timevar]][j] < period){
            invisible()
          } else {
            
            ## take the game with them matching id and time variable
            id <- unlist(data[[idvar]])[j]
            game <- unlist(data[[timevar]])[j]
            subs <- data[ (unlist(data[[idvar]]) == id) &
                            (unlist(data[[timevar]]) %in% rev(1:game)[1:period]),]
            
            ## if the time variable yields more observations than the lookback period,
            if(nrow(subs) >= period){
              train_inds[j] <- 1
              subs <- subs[order(subs[[timevar]]),]
              targets[j,] <- c(unlist(tail(as(subs[,1:length(outcomes)],
                                              'matrix'),1)[1:length(outcomes)]))
              subs[[idvar]] <- NULL
              mat <- as(subs[,-1],
                        'matrix')
              
              ## if we haven't made a samples array yet, the X of (X,Y),
              ## we initialize below to match the dimensions of our data
              if(!made_samples){
                save_cols <- colnames(mat)
                samples <- array(0, dim = c(nrow(data),
                                            nrow(mat),
                                            ncol(mat)))
                made_samples <- T
              }
              samples[j,,] <- mat
            }
          }
        }}
      if(!load_tensors) {
        # indices to keep
        if (!any(train_inds != 0)) {
          train_inds <- 1 * (data[[timevar]] >= period)
        }
        train_inds <- which(train_inds == 1)
        train_inds <- train_inds[!(train_inds %in% exclude_inds)]
        write.csv(train_inds, 'train_inds.csv', row.names = F)
        if (length(train_inds) == 0) {
          stop(
            "Your training indices are of length 0: are your time variable, period, and/or id variable set up correcly?"
          )
        }
      }
      if(!load_tensors){
        samples <- samples[train_inds,,]
        targets <- targets[train_inds,]
      }
      if(save_tensors){
        save(samples,
             targets,
             train_inds,
             file = tensor_file)
      }
      
      ## function needed for fitting 
      train_gen <- function(){
        return(list(
          samples,
          targets
        ))
      }
      
      ## keras model construction
      model <- base_model %>%
        layer_conv_2d(filters = units_conv1,
                      kernel_size = rep(kernel_size1,2),
                      activation = activation_conv1,
                      input_shape = c(28,28,1),
                      kernel_regularizer = regularizer_l1_l2(l1 = l1_conv,
                                                             l2 = l2_conv),
                      padding = "same") %>%
        layer_max_pooling_2d(pool_size = rep(pool_size1,2)) %>%
        layer_conv_2d(filters = units_conv2,
                      kernel_size = rep(kernel_size2,2),
                      activation = activation_conv2,
                      kernel_regularizer = regularizer_l1_l2(l1 = l1_conv,
                                                             l2 = l2_conv)) %>%
        layer_max_pooling_2d(pool_size = rep(pool_size2,2)) %>% 
        layer_dropout(rate = dr_conv) %>% 
        layer_flatten() %>%
        layer_dense(units = units_dense1,
                    activation = activation_dense,
                    kernel_regularizer = 
                      regularizer_l1_l2(l1 = l1_dense,
                                        l2 = l2_dense)) %>%
        layer_dense(units = units_dense2,
                    activation = activation_dense,
                    kernel_regularizer = 
                      regularizer_l1_l2(l1 = l1_dense,
                                        l2 = l2_dense)) %>%
        layer_dropout(rate = dr_dense) %>% 
        layer_dense(units = length(outcomes),
                    activation = 'softmax')
      
      ## fit model
      model %>% compile(
        metrics = metrics,
        loss = loss
      )
      message <- 'starting_history'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      history <- model %>% 
        fit(
          train_gen,
          epochs = epochs,
          steps_per_epoch = floor(nrow(targets) / batch_size),
          batch_size = nrow(targets) / floor(nrow(targets) / batch_size),
          verbose = verbose
        )
      message <- 'finished_history'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      return(list(
        "model" = model,
        "history" = history,
        "targets" = targets,
        "samples" = samples,
        "ids" = data[[idvar]],
        "timevars" = data[[timevar]],
        "predictors" = predictors,
        "train_inds" = train_inds,
        "recipe" = rcp,
        "save_cols" = save_cols
      ))
    },
    predict = function(object, 
                       newdata, 
                       ...) {
      
      message <- 'starting_2_predict'
      write.csv(message,file = paste0(message,'.csv'),row.names = F)
      ## if we are making fitted predictions, no need to waste time making new tensors
      if(length(newdata[[idvar]]) == length(object$ids) &
         !((any(newdata[[idvar]] != object$ids)) |
           (any(newdata[[timevar]] != object$timevars)))){
        ## use the old data to predict, no need to make new tensors
        ## make predictions on new data
        pred_gen <- function(){
          return(list(
            object$samples#[1:length(object$train_inds),,]
          ))
        }
        zeroes <- rep(0,nrow(newdata) - nrow(object$samples))
        message <- 'about_to_make predictions'
        write.csv(message,file = paste0(message,'.csv'),row.names = F)
        preds <- predict(object$model,
                         pred_gen,
                         steps = 1)
        message <- 'made_predictions'
        write.csv(message,file = paste0(message,'.csv'),row.names = F)
        vec <- cbind(rep(0,nrow(newdata)))
        if(length(outcomes) > 1){
          for(j in 2:length(outcomes)){
            vec <- cbind(vec,cbind(vec)[,1])
          }
        }
        vec <- preds #[object$train_inds,] <- preds
        # vec[-object$train_inds,] <- zeroes
        rownames(vec) <- 1:nrow(vec)
        #rownames(vec)[object$train_inds] <- paste0("train_",rownames(vec)[object$train_inds])
        vec
      } else {
        
        ## if we have to make new tensors
        data <- newdata
        rcp_jc <- object$recipe %>%
          prep %>%
          bake(new_data = as.data.frame(data))
        data <- cbind(data[,!(colnames(data) %in% object$predictors)],
                      rcp_jc) %>% 
          as.data.frame
        made_samples <- F
        j <- 0
        test_inds <- rep(0,nrow(data))
        
          for (j in 1:nrow(data)) {
            if (data[[timevar]][j] < period) {
              invisible()
            } else {
              id <- unlist(data[[idvar]])[j]
              game <- unlist(data[[timevar]])[j]
              subs <- data[(unlist(data[[idvar]]) == id) &
                             (unlist(data[[timevar]]) %in% rev(1:game)[1:period]), ]
              if (nrow(subs) >= period) {
                test_inds[j] <- 1
                subs <- subs[order(subs[[timevar]]), ]
                subs[[idvar]] <- NULL
                mat <- as(subs,
                          'matrix')
                if (!made_samples) {
                  write.csv(mat, file = 'matrixx_test.csv', row.names = F)
                  samples <- array(0, dim = c(nrow(data),
                                              nrow(mat),
                                              ncol(mat)))
                  made_samples <- T
                }
                #mat <- mat[,object$save_cols]
                samples[j, , ] <- mat
              }
            }
          }
        
        ## indices to keep
        if(!any(test_inds != 0)){
          test_inds <- 1*(data[[timevar]] >= period)
        }
        test_inds <- which(test_inds == 1)
        
        ## function needed for predicting
        pred_gen <- function(){
          return(list(
            samples[test_inds,,]
          ))
        }
        
        ## replace indices with timevar less than required with 0s
        zeroes <- rep(0,nrow(newdata) - length(test_inds))
        preds <- predict(object$model,
                         pred_gen,
                         steps = 1)
        vec <- cbind(rep(0,nrow(newdata)))
        if(length(outcomes) > 1){
          for(j in 2:length(outcomes)){
            vec <- cbind(vec,cbind(vec)[,1])
          }
        }
        vec[test_inds,] <- preds
        vec[-test_inds,] <- zeroes
        vec
      }
    },
    varimp = function(object, ...) {
      NULL
    }
  )
}
CNNModel <- MLModelFunction(CNN)
##################################################################################
## load MNIST training data
load('mnist_train_conv.RData')
colnames(rec$template)[-ncol(rec$template)] <- substr(
  colnames(rec$template)[-ncol(rec$template)],
  3,
  nchar(colnames(rec$template)[-ncol(rec$template)])
)
colrename <- function(x,names){
  colnames(x) <- names
  return(x)
}
Y <- cbind(sapply(0:9,
                  function(y){
                    1*(as.character(rec$template$Y) == 
                       as.character(y))
                  })) %>% 
  colrename(paste0("r",1:10))
rec$template$Y <- NULL
rec$template <- bind_cols(rec$template,Y)
rm(Y)

  set.seed(52245)
  ## fit the network
  fitt <- MachineShop::fit(cbind(r1,
                                 r2,
                                 r3,
                                 r4,
                                 r5,
                                 r6,
                                 r7,
                                 r8,
                                 r9,
                                 r10) ~ .,
                           data = as.data.frame(rec$template),
                           model = CNNModel(
                             batch_size = 32,
                             epochs = 5,
                             verbose = T,
                             units_conv1 = 246,
                             units_conv2 = 58,
                             units_dense1 = 104,
                             units_dense2 = 124,
                             kernel_size1 = 3,
                             kernel_size2 = 3,
                             dr_conv = 0.492097344,
                             dr_dense = 0.354213828,
                             load_tensors = T,
                             save_tensors = F,
                             tensor_file = "tensors_full_train.RData"
                           ))
  save(fitt,file = "mnist_final_fit.RData")
  
  ## load and prep the test data 
  load('mnist_test_conv.RData')
  rec_test <- rec
  colnames(rec_test$template)[-ncol(rec_test$template)] <- substr(
    colnames(rec_test$template)[-ncol(rec_test$template)],
    3,
    nchar(colnames(rec_test$template)[-ncol(rec_test$template)])
  )
  Y <- cbind(sapply(0:9,
                    function(y){
                      1*(as.character(rec_test$template$Y) == 
                         as.character(y))
                    })) %>% 
    colrename(paste0("r",1:10))
  rec_test$template$Y <- NULL
  
  ## make predictions, evaluate results for out-of-sample performance
  pr <- predict(fitt,
                newdata = as.data.frame(rec_test$template))
  rp <- Y
  inds2keep <- which(rowSums(abs(pr)) > 0)
  pr <- pr[inds2keep,]
  rp <- rp[inds2keep,]
  rp <- factor(apply(rp,1,function(x)which(x == 1)))
  output <- as.numeric(unlist(performance(rp,pr,metrics = 'accuracy')))[1]
  names(output) <- 'accuracy'
  print(output)
  save(pr,rp,output,file = 'mnist_test_performance.RData')
  
  
  
